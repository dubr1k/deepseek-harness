/** Browser-safe dedicated Connection RPC contract owned by codex-auth. */

import type { ConnectionRpcResult as RpcResult } from '@deepseek-ai/dsh-client-connection'

/** Logical channel registered by the plugin's Host half and called by its browser half. */
export const CODEX_AUTH_RPC_CHANNEL = '/api'
export const CODEX_AUTH_RPC_NAMESPACE = 'codex-auth'

/** One official codex CLI login flow. */
export type CodexAuthLoginMode = 'browser' | 'device'

/** Value-free login state; token values are intentionally absent. */
export interface CodexAuthStatusView {
  available: boolean
  configured: boolean
  authMode?: string
  codexVersion?: string
  tokenExpiresAt?: string
  lastRefreshAt?: string
  /** Locally decoded ChatGPT account claim; never a credential. */
  accountId?: string
  /** Locally decoded ChatGPT plan claim, when present; never remotely probed. */
  planType?: string
  credentialRef: string
  authFileExists: boolean
}

/** Value-free account quota snapshot for settings and the composer dock. */
export interface CodexUsageView {
  /** Backend-reported plan claim for the account; absent when unknown. */
  planType?: string
  /** Remaining percentage (0-100) of the seven-day usage window; absent when unknown. */
  weeklyRemainingPercent?: number
  /** Remaining percentage of the five-hour window; absent if the plan has none. */
  fiveHourRemainingPercent?: number
  /** ISO timestamp of the five-hour window reset, when reported. */
  fiveHourResetAt?: string
  /** ISO timestamp of the seven-day usage window's next reset; absent when unknown. */
  weeklyResetAt?: string
}

/** Browser-safe face consumed by the settings card. */
export interface CodexAuthRpcClient {
  /** Read or persist one conversation's Fast preference. Omission reads only. */
  fastMode(sessionId: string, enabled?: boolean, signal?: AbortSignal): Promise<RpcResult<{ fastMode: CodexFastModeView }>>
  /** Read the value-free codex login state. */
  status(signal?: AbortSignal): Promise<RpcResult<{ status: CodexAuthStatusView }>>
  /** Read the value-free five-hour and weekly quota snapshot from the ChatGPT backend. */
  usage(signal?: AbortSignal): Promise<RpcResult<{ usage: CodexUsageView }>>
  /** Start one official codex CLI login flow. */
  login(mode: CodexAuthLoginMode, signal?: AbortSignal): Promise<RpcResult<{ started: boolean }>>
}

export interface CodexFastModeView {
  enabled: boolean
  source: 'profile' | 'session'
}

/** Minimal generic Connection caller required by this plugin. */
export interface CodexAuthConnectionRpc {
  call(
    channel: string,
    endpoint: string,
    payload: unknown,
    signal?: AbortSignal,
  ): Promise<RpcResult<unknown>>
}

/** Build the browser face over Connection's plugin-owned unary channel. */
export function createCodexAuthRpcClient(rpc: CodexAuthConnectionRpc): CodexAuthRpcClient {
  return {
    fastMode: async (sessionId, enabled, signal) => {
      const result = await rpc.call(CODEX_AUTH_RPC_CHANNEL, `${CODEX_AUTH_RPC_NAMESPACE}/fast-mode`, {
        sessionId, ...enabled === undefined ? {} : { enabled },
      }, signal)
      if (!result.ok) return result
      const value = isRecord(result.value) ? result.value.fastMode : undefined
      return isRecord(value) && typeof value.enabled === 'boolean' && (value.source === 'profile' || value.source === 'session')
        ? { ok: true, value: { fastMode: { enabled: value.enabled, source: value.source } } }
        : invalidResponse('fast-mode')
    },
    status: async (signal) => {
      const result = await rpc.call(CODEX_AUTH_RPC_CHANNEL, `${CODEX_AUTH_RPC_NAMESPACE}/status`, {}, signal)
      if (!result.ok) return result
      const status = parseStatusResult(result.value)
      return status === undefined ? invalidResponse('status') : { ok: true, value: { status } }
    },
    usage: async (signal) => {
      const result = await rpc.call(CODEX_AUTH_RPC_CHANNEL, `${CODEX_AUTH_RPC_NAMESPACE}/usage`, {}, signal)
      if (!result.ok) return result
      const usage = parseUsageResult(result.value)
      return usage === undefined ? invalidResponse('usage') : { ok: true, value: { usage } }
    },
    login: async (mode, signal) => {
      const result = await rpc.call(CODEX_AUTH_RPC_CHANNEL, `${CODEX_AUTH_RPC_NAMESPACE}/login`, { mode }, signal)
      if (!result.ok) return result
      return isRecord(result.value) && typeof result.value.started === 'boolean'
        ? { ok: true, value: { started: result.value.started } }
        : invalidResponse('login')
    },
  }
}

function parseStatusResult(value: unknown): CodexAuthStatusView | undefined {
  if (!isRecord(value) || !isRecord(value.status)) return undefined
  const status = value.status
  if (
    typeof status.available !== 'boolean'
    || typeof status.configured !== 'boolean'
    || typeof status.credentialRef !== 'string'
    || typeof status.authFileExists !== 'boolean'
  ) return undefined
  for (const key of ['authMode', 'codexVersion', 'tokenExpiresAt', 'lastRefreshAt', 'accountId', 'planType'] as const) {
    if (status[key] !== undefined && typeof status[key] !== 'string') return undefined
  }
  return {
    available: status.available,
    configured: status.configured,
    ...typeof status.authMode === 'string' ? { authMode: status.authMode } : {},
    ...typeof status.codexVersion === 'string' ? { codexVersion: status.codexVersion } : {},
    ...typeof status.tokenExpiresAt === 'string' ? { tokenExpiresAt: status.tokenExpiresAt } : {},
    ...typeof status.lastRefreshAt === 'string' ? { lastRefreshAt: status.lastRefreshAt } : {},
    ...typeof status.accountId === 'string' ? { accountId: status.accountId } : {},
    ...typeof status.planType === 'string' ? { planType: status.planType } : {},
    credentialRef: status.credentialRef,
    authFileExists: status.authFileExists,
  }
}

function parseUsageResult(value: unknown): CodexUsageView | undefined {
  if (!isRecord(value) || !isRecord(value.usage)) return undefined
  const usage = value.usage
  if (usage.planType !== undefined && typeof usage.planType !== 'string') return undefined
  for (const key of ['weeklyResetAt', 'fiveHourResetAt'] as const) {
    if (usage[key] !== undefined && typeof usage[key] !== 'string') return undefined
  }
  for (const key of ['weeklyRemainingPercent', 'fiveHourRemainingPercent'] as const) {
    const percent = usage[key]
    if (percent !== undefined && (!Number.isSafeInteger(percent) || (percent as number) < 0 || (percent as number) > 100)) return undefined
  }
  return {
    ...typeof usage.planType === 'string' ? { planType: usage.planType } : {},
    ...typeof usage.weeklyRemainingPercent === 'number' ? { weeklyRemainingPercent: usage.weeklyRemainingPercent } : {},
    ...typeof usage.weeklyResetAt === 'string' ? { weeklyResetAt: usage.weeklyResetAt } : {},
    ...typeof usage.fiveHourRemainingPercent === 'number' ? { fiveHourRemainingPercent: usage.fiveHourRemainingPercent } : {},
    ...typeof usage.fiveHourResetAt === 'string' ? { fiveHourResetAt: usage.fiveHourResetAt } : {},
  }
}

function invalidResponse(endpoint: string): RpcResult<never> {
  return {
    ok: false,
    error: {
      code: 'internal',
      message: `codex-auth: invalid ${endpoint} response from Host`,
      details: {},
    },
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
