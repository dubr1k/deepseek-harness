/** Unified four-card settings surface for the Codex Capability Bundle. */
import { useCallback, useEffect, useId, useRef, useState, useSyncExternalStore } from 'react'
import type { ChangeEvent, ReactNode } from 'react'
import type { ConfigForm, ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client'
import {
  Button, IconChevronDownOutlineMedium, IconRefreshOutlineMedium, StateDot,
} from '@deepseek-ai/dsh-client-ui-primitives'
import type { CodexAuthRpcClient, CodexAuthStatusView, CodexUsageView } from '../rpc-contract.ts'
import type { CodexAuthKey } from './locales.ts'
import { IMAGE_MODELS, IMAGE_SIZES, isImageSize, supportsImageQuality, supportsImageSize } from '../image-options.ts'
import type { ImageQuality, ImageSize } from '../image-options.ts'
import classes from './CodexCapabilitySettings.module.css'

export interface LlmSettingsView {
  longContextEnabled: boolean
  fastModeEnabled?: boolean
  excludedModelIds?: string[]
}

export interface SearchSettingsView {
  enabled: boolean
  mode: 'live' | 'cached' | 'indexed'
  contextSize: 'low' | 'medium' | 'high'
  fallbackModel: string
  maxOutputTokens: number
}

export interface ImageSettingsView {
  enabled: boolean
  model: string
  n: number
  size: ImageSize
  quality: ImageQuality
  background: 'auto' | 'opaque' | 'transparent'
}

export interface CodexCapabilitySettingsProps {
  rpc: CodexAuthRpcClient
  t: (key: CodexAuthKey) => string
  subscribe: (listener: () => void) => () => void
  llmScope: ConfigForm<LlmSettingsView>
  searchScope: ConfigForm<SearchSettingsView>
  imageScope: ConfigForm<ImageSettingsView>
}

type LoadState = 'loading' | 'ready' | 'error'

/** One navigable GPT Auth section containing Auth/LLM, Search, and Image Creation cards. */
export function CodexCapabilitySettings({
  rpc,
  t,
  subscribe,
  llmScope,
  searchScope,
  imageScope,
}: CodexCapabilitySettingsProps): ReactNode {
  const [status, setStatus] = useState<CodexAuthStatusView | null>(null)
  const [usage, setUsage] = useState<CodexUsageView | null>(null)
  const [usageBusy, setUsageBusy] = useState(true)
  const [loadState, setLoadState] = useState<LoadState>('loading')
  const [error, setError] = useState<string | null>(null)
  const [loginBusy, setLoginBusy] = useState(false)
  const [refreshBusy, setRefreshBusy] = useState(false)
  const [tick, setTick] = useState(0)
  const [searchExpanded, setSearchExpanded] = useState(false)
  const [imageExpanded, setImageExpanded] = useState(false)
  const searchRegionId = useId()
  const imageRegionId = useId()
  const llm = useScope(llmScope)
  const search = useScope(searchScope)
  const image = useScope(imageScope)

  useEffect(() => subscribe(() => { setTick(value => value + 1) }), [subscribe])

  const load = useCallback(async () => {
    setRefreshBusy(true)
    setError(null)
    const minDelay = new Promise(resolve => setTimeout(resolve, 500))
    try {
      const [result] = await Promise.all([rpc.status(), minDelay])
      if (!result.ok) {
        setLoadState(previous => previous === 'ready' ? previous : 'error')
        setError(result.error.message || t('statusFailed'))
        return
      }
      setStatus(result.value.status)
      setLoadState('ready')
    } catch (cause) {
      setLoadState(previous => previous === 'ready' ? previous : 'error')
      setError(messageOf(cause, t('statusFailed')))
    } finally {
      setRefreshBusy(false)
    }
  }, [rpc, t])

  const loadUsage = useCallback(async () => {
    setUsageBusy(true)
    try {
      const result = await rpc.usage()
      if (result.ok) setUsage(result.value.usage)
    } catch {
      /* quota facts are optional */
    } finally {
      setUsageBusy(false)
    }
  }, [rpc])

  useEffect(() => { void load(); void loadUsage() }, [load, loadUsage, tick])

  const startLogin = useCallback(async (mode: 'browser' | 'device') => {
    setLoginBusy(true)
    setError(null)
    try {
      const result = await rpc.login(mode)
      if (!result.ok) setError(result.error.message || t('loginFailed'))
    } catch (cause) {
      setError(messageOf(cause, t('loginFailed')))
    } finally {
      setLoginBusy(false)
    }
  }, [rpc, t])

  const searchUnavailable = status?.configured !== true
  const imageUnavailable = status?.configured !== true || status.planType?.toLowerCase() === 'free'

  return (
    <section className={classes.bundle}>
      <header className={classes.bundleHeader}>
        <div>
          <div className={classes.bundleTitleLine}>
            <h1 className={classes.bundleTitle}>{t('title')}</h1>
            <StatusDot loadState={loadState} status={status} t={t} />
          </div>
          <p className={classes.bundleIntro}>{t('intro')}</p>
        </div>
      </header>

      <div className={classes.cards}>
        {/* Auth / Login Card */}
        <article className={classes.card}>
          <CardHeading title={t('authCardTitle')} intro={t('authCardIntro')} />
          <AuthBody status={status} usage={usage} usageBusy={usageBusy} loadState={loadState} t={t} />
          <div className={classes.actions}>
            <Button
              variant="primary"
              className={classes.compactButton}
              disabled={loginBusy || status?.available !== true}
              onClick={() => { void startLogin('browser') }}
            >
              {loginBusy ? t('startingLogin') : status?.configured === true ? t('relogin') : t('login')}
            </Button>
            <Button
              variant="outline"
              className={classes.compactButton}
              disabled={loginBusy || status?.available !== true}
              onClick={() => { void startLogin('device') }}
            >
              {t('deviceLogin')}
            </Button>
            <Button
              variant="ghost"
              className={`${classes.compactButton} ${classes.refresh}`}
              icon={(
                <span className={refreshBusy ? classes.spinIcon : classes.staticIcon}>
                  <IconRefreshOutlineMedium size={16} />
                </span>
              )}
              disabled={refreshBusy}
              onClick={() => { void load(); void loadUsage() }}
            >
              {refreshBusy ? t('refreshing') : t('refresh')}
            </Button>
          </div>
          <p className={classes.privacyNotice}>{t('privacyNotice')}</p>
        </article>

        {/* LLM Context Card */}
        <article className={`${classes.card} ${classes.contextCard}`}>
          <CardHeading
            title={t('contextCardTitle')}
            intro={t('contextCardIntro')}
            badge={llm.value === undefined
              ? undefined
              : llm.value.longContextEnabled ? t('contextLongBadge') : t('contextStandardBadge')}
            action={llm.value === undefined ? null : (
              <Switch
                label={t('enableLongContext')}
                checked={llm.value.longContextEnabled}
                disabled={!llm.writable}
                onChange={next => { void writer(llmScope, setError, t)('longContextEnabled', next) }}
              />
            )}
          />
          <SettingsState snapshot={llm} t={t}>
            <div className={classes.contextDetails}>
              <CardHeading
                title={t('fastModeTitle')}
                intro={t('fastModeBehavior')}
                action={llm.value === undefined ? null : (
                  <Switch
                    label={t('enableFastMode')}
                    checked={llm.value.fastModeEnabled === true}
                    disabled={!llm.writable}
                    onChange={next => { void writer(llmScope, setError, t)('fastModeEnabled', next) }}
                  />
                )}
              />
              <p className={classes.contextWarning}>{t('fastModeWarning')}</p>
            </div>
            <div className={classes.contextDetails}>
              <p>{t('contextBehavior')}</p>
              <p className={classes.contextWarning}>{t('contextWarning')}</p>
            </div>
            {llm.value === undefined ? null : (
              <ModelExclusionControl scope={llmScope} snapshot={llm} t={t} onError={setError} />
            )}
          </SettingsState>
        </article>

        {/* Web Search Card */}
        <article className={classes.card} data-collapsed={!searchExpanded}>
          <CardHeading
            title={t('searchCardTitle')}
            intro={t('searchCardIntro')}
            badge={status !== null && !status.configured ? t('availableAfterLogin') : undefined}
            tone={status?.configured === false ? 'warning' : 'neutral'}
            action={(
              <>
                {search.value === undefined ? null : (
                  <Switch
                    label={t('enableSearch')}
                    checked={search.value.enabled}
                    disabled={!search.writable || searchUnavailable}
                    onChange={next => { void writer(searchScope, setError, t)('enabled', next) }}
                  />
                )}
                <DisclosureButton
                  expanded={searchExpanded}
                  controls={searchRegionId}
                  label={searchExpanded ? t('collapseSearch') : t('expandSearch')}
                  onClick={() => { setSearchExpanded(value => !value) }}
                />
              </>
            )}
          />
          <CollapsibleRegion id={searchRegionId} expanded={searchExpanded}>
            <SettingsState snapshot={search} t={t}>
              {search.value === undefined ? null : (
                <SearchControls
                  scope={searchScope}
                  snapshot={search}
                  t={t}
                  unavailable={searchUnavailable}
                  onError={setError}
                />
              )}
            </SettingsState>
          </CollapsibleRegion>
        </article>

        {/* Image Creation Card */}
        <article className={classes.card} data-collapsed={!imageExpanded}>
          <CardHeading
            title={t('imageCardTitle')}
            intro={t('imageCardIntro')}
            badge={status === null
              ? undefined
              : !status.configured
                ? t('availableAfterLogin')
                : status.planType?.toLowerCase() === 'free'
                  ? t('unavailableFree')
                  : undefined}
            tone={!status?.configured || status.planType?.toLowerCase() === 'free' ? 'warning' : 'neutral'}
            action={(
              <>
                {image.value === undefined ? null : (
                  <Switch
                    label={t('enableImage')}
                    checked={image.value.enabled}
                    disabled={!image.writable || imageUnavailable}
                    onChange={next => { void writer(imageScope, setError, t)('enabled', next) }}
                  />
                )}
                <DisclosureButton
                  expanded={imageExpanded}
                  controls={imageRegionId}
                  label={imageExpanded ? t('collapseImage') : t('expandImage')}
                  onClick={() => { setImageExpanded(value => !value) }}
                />
              </>
            )}
          />
          <CollapsibleRegion id={imageRegionId} expanded={imageExpanded}>
            <SettingsState snapshot={image} t={t}>
              {image.value === undefined ? null : (
                <ImageControls
                  scope={imageScope}
                  snapshot={image}
                  t={t}
                  unavailable={imageUnavailable}
                  onError={setError}
                />
              )}
            </SettingsState>
          </CollapsibleRegion>
        </article>
      </div>

      {error === null ? null : <p className={classes.error} role="alert">{error}</p>}
      {status?.available === true && !status.configured ? <p className={classes.hint}>{t('loginHint')}</p> : null}
    </section>
  )
}

function CardHeading({
  title,
  intro,
  badge,
  action,
  tone = 'neutral',
}: {
  title: string
  intro: string
  badge?: string | undefined
  action?: ReactNode
  tone?: 'neutral' | 'warning'
}): ReactNode {
  return (
    <header className={classes.cardHeader}>
      <div className={classes.cardIdentity}>
        <div className={classes.cardTitleLine}>
          <h2 className={classes.cardTitle}>{title}</h2>
          {badge === undefined ? null : <span className={classes.badge} data-tone={tone}>{badge}</span>}
        </div>
        <p className={classes.cardIntro}>{intro}</p>
      </div>
      {action !== undefined ? <div className={classes.cardAction}>{action}</div> : null}
    </header>
  )
}

function DisclosureButton({
  expanded,
  controls,
  label,
  onClick,
}: {
  expanded: boolean
  controls: string
  label: string
  onClick: () => void
}): ReactNode {
  return (
    <Button
      variant="ghost"
      size="sm"
      className={classes.disclosureButton}
      aria-expanded={expanded}
      aria-controls={controls}
      aria-label={label}
      title={label}
      onClick={onClick}
    >
      <span className={classes.disclosureIcon} data-expanded={expanded} aria-hidden="true">
        <IconChevronDownOutlineMedium size={14} />
      </span>
    </Button>
  )
}

function CollapsibleRegion({
  id,
  expanded,
  children,
}: {
  id: string
  expanded: boolean
  children: ReactNode
}): ReactNode {
  return (
    <div
      id={id}
      className={classes.collapsibleRegion}
      data-expanded={expanded}
      aria-hidden={!expanded}
    >
      <div className={classes.collapsibleInner}>{children}</div>
    </div>
  )
}

function StatusDot({
  loadState,
  status,
  t,
}: {
  loadState: LoadState
  status: CodexAuthStatusView | null
  t: CodexCapabilitySettingsProps['t']
}): ReactNode {
  const state = loadState === 'loading'
    ? 'ongoing'
    : loadState === 'error' || status === null
      ? 'error'
      : status.configured
        ? 'done'
        : status.available
          ? 'warning'
          : 'error'
  const label = loadState === 'loading'
    ? t('refreshing')
    : status?.configured === true
      ? t('active')
      : status?.available === false
        ? t('notAvailable')
        : t('loggedOut')
  return (
    <span className={classes.titleDot} title={label} aria-label={label} role="status">
      <StateDot state={state} />
      <span className={classes.srOnly}>{label}</span>
    </span>
  )
}

function AuthBody({
  status,
  usage,
  usageBusy,
  loadState,
  t,
}: {
  status: CodexAuthStatusView | null
  usage: CodexUsageView | null
  usageBusy: boolean
  loadState: LoadState
  t: CodexCapabilitySettingsProps['t']
}): ReactNode {
  if (status === null) {
    if (loadState === 'loading') {
      return (
        <div className={classes.authDashboard}>
          <dl className={classes.facts}>
            <Fact label={t('plan')} value={<span className={classes.skeletonInlineValue} />} />
            <Fact label={t('weeklyReset')} value={<span className={classes.skeletonInlineValue} />} />
          </dl>
          <div className={classes.quotaContainer}>
            <div className={classes.quotaInfo}>
              <span className={classes.quotaLabel}>{t('quotaRemaining')}</span>
              <span className={classes.quotaQuerying}>
                <span className={classes.queryingSpinner} aria-hidden="true" />
                <span>{t('queryingQuota')}</span>
              </span>
            </div>
            <div className={classes.progressTrack}>
              <div className={classes.shimmerTrack} aria-hidden="true" />
            </div>
          </div>
        </div>
      )
    }
    return null
  }

  const remainingPercent = usage?.weeklyRemainingPercent
  const showQuerying = usageBusy && remainingPercent === undefined

  return (
    <div className={classes.authDashboard}>
      <dl className={classes.facts}>
        <Fact label={t('plan')} value={status.planType === undefined ? t('unknownPlan') : `${titleCase(status.planType)} plan`} />
        <Fact
          label={t('weeklyReset')}
          value={
            usage?.weeklyResetAt !== undefined
              ? localDate(usage.weeklyResetAt)
              : usageBusy
                ? <span className={classes.skeletonInlineValue} />
                : '—'
          }
        />
      </dl>
      <div className={classes.quotaContainer}>
        <div className={classes.quotaInfo}>
          <span className={classes.quotaLabel}>{t('quotaRemaining')}</span>
          {showQuerying ? (
            <span className={classes.quotaQuerying}>
              <span className={classes.queryingSpinner} aria-hidden="true" />
              <span>{t('queryingQuota')}</span>
            </span>
          ) : remainingPercent !== undefined ? (
            <span
              className={classes.quotaValue}
              data-tone={quotaTone(remainingPercent)}
            >
              {remainingPercent}%
            </span>
          ) : (
            <span className={classes.quotaValue}>—</span>
          )}
        </div>
        <div className={classes.progressTrack}>
          {showQuerying ? (
            <div className={classes.shimmerTrack} aria-hidden="true" />
          ) : remainingPercent !== undefined ? (
            <div
              className={classes.progressFill}
              data-tone={quotaTone(remainingPercent)}
              style={{ width: `${Math.max(0, Math.min(100, remainingPercent))}%` }}
            />
          ) : null}
        </div>
      </div>
    </div>
  )
}

function Fact({ label, value }: { label: string; value: ReactNode }): ReactNode {
  return (
    <div className={classes.fact}>
      <dt>{label}</dt>
      <dd>{value}</dd>
    </div>
  )
}

function SettingsState<T>({
  snapshot,
  t,
  children,
}: {
  snapshot: ConfigFormSnapshot<T>
  t: CodexCapabilitySettingsProps['t']
  children: ReactNode
}): ReactNode {
  if (snapshot.status === 'loading') {
    return (
      <div className={classes.skeletonFormRows} role="status" aria-live="polite" aria-busy="true">
        <span className={classes.srOnly}>{t('settingsLoading')}</span>
        <div className={classes.skeletonRow} aria-hidden="true" />
        <div className={classes.skeletonRow} aria-hidden="true" />
        <div className={classes.skeletonRow} aria-hidden="true" />
        <div className={classes.skeletonRow} aria-hidden="true" />
      </div>
    )
  }
  if (snapshot.status === 'unavailable' || snapshot.value === undefined) {
    return <p className={classes.loading}>{t('settingsUnavailable')}</p>
  }
  return children
}

function ModelExclusionControl({
  scope,
  snapshot,
  t,
  onError,
}: {
  scope: ConfigForm<LlmSettingsView>
  snapshot: ConfigFormSnapshot<LlmSettingsView>
  t: CodexCapabilitySettingsProps['t']
  onError: (message: string | null) => void
}): ReactNode {
  const ids = (snapshot.value?.excludedModelIds ?? []).join(', ')
  const [draft, setDraft] = useState(ids)
  const [saving, setSaving] = useState(false)
  const pending = useRef(false)
  const hintId = useId()
  useEffect(() => { setDraft(ids) }, [ids, scope])
  const save = (): void => {
    if (pending.current || !snapshot.writable) return
    const next = [...new Set(draft.split(',').map(id => id.trim()).filter(Boolean))]
    if (JSON.stringify(next) !== JSON.stringify(snapshot.value?.excludedModelIds ?? [])) {
      pending.current = true
      setSaving(true)
      void writer(scope, onError, t)('excludedModelIds', next).finally(() => {
        pending.current = false
        setSaving(false)
      })
    }
  }
  return (
    <div className={classes.formRows}>
      <Control label={t('excludedModelIds')}>
        <input aria-label={t('excludedModelIds')} aria-describedby={hintId} value={draft} disabled={!snapshot.writable || saving}
          onChange={event => { if (!pending.current) setDraft(event.target.value) }} onBlur={save}
          onKeyDown={event => { if (event.key === 'Enter') { event.preventDefault(); save() } }} />
      </Control>
      <p className={classes.imageHint} id={hintId}>{t('excludedModelIdsHint')}</p>
    </div>
  )
}

function SearchControls({
  scope,
  snapshot,
  t,
  unavailable,
  onError,
}: {
  scope: ConfigForm<SearchSettingsView>
  snapshot: ConfigFormSnapshot<SearchSettingsView>
  t: CodexCapabilitySettingsProps['t']
  unavailable: boolean
  onError: (message: string | null) => void
}): ReactNode {
  const value = snapshot.value as SearchSettingsView
  const disabled = !snapshot.writable || unavailable || !value.enabled
  const write = writer(scope, onError, t)
  return (
    <div className={classes.formRows} data-dimmed={!value.enabled || unavailable}>
      <Control label={t('searchMode')}>
        <select aria-label={t('searchMode')} value={value.mode} disabled={disabled} onChange={event => { void write('mode', event.target.value) }}>
          <option value="live">{t('live')}</option><option value="cached">{t('cached')}</option><option value="indexed">{t('indexed')}</option>
        </select>
      </Control>
      <Control label={t('contextSize')}>
        <select aria-label={t('contextSize')} value={value.contextSize} disabled={disabled} onChange={event => { void write('contextSize', event.target.value) }}>
          <option value="low">{t('low')}</option><option value="medium">{t('medium')}</option><option value="high">{t('high')}</option>
        </select>
      </Control>
      <Control label={t('fallbackModel')}>
        <input aria-label={t('fallbackModel')} value={value.fallbackModel} disabled={disabled} onChange={event => { void write('fallbackModel', event.target.value) }} />
      </Control>
      <Control label={t('maxOutputTokens')}>
        <input aria-label={t('maxOutputTokens')} type="number" min={1} step={1} value={value.maxOutputTokens} disabled={disabled} onChange={event => { void write('maxOutputTokens', Number(event.target.value)) }} />
      </Control>
    </div>
  )
}

function ImageControls({
  scope,
  snapshot,
  t,
  unavailable,
  onError,
}: {
  scope: ConfigForm<ImageSettingsView>
  snapshot: ConfigFormSnapshot<ImageSettingsView>
  t: CodexCapabilitySettingsProps['t']
  unavailable: boolean
  onError: (message: string | null) => void
}): ReactNode {
  const value = snapshot.value as ImageSettingsView
  const disabled = !snapshot.writable || unavailable || !value.enabled
  const write = writer(scope, onError, t)
  const sizesId = useId()
  const sizeHintId = useId()
  const [sizeDraft, setSizeDraft] = useState<string>(value.size)
  useEffect(() => { setSizeDraft(value.size) }, [value.size])
  const saveSize = (): void => {
    const size = sizeDraft.trim()
    if (!isImageSize(size) || !supportsImageSize(value.model, size)) {
      onError(t('invalidImageSize'))
      return
    }
    if (size !== value.size) void write('size', size)
    else onError(null)
  }
  return (
    <div className={classes.formRows} data-dimmed={!value.enabled || unavailable}>
      <Control label={t('imageModel')}>
        <select aria-label={t('imageModel')} value={value.model} disabled={disabled} onChange={event => { void write('model', event.target.value) }}>
          {!IMAGE_MODELS.some(model => model === value.model) && <option value={value.model}>{value.model}</option>}
          {IMAGE_MODELS.map(model => <option key={model} value={model}>{model}</option>)}
        </select>
      </Control>
      <Control label={t('defaultImageCount')}>
        <select aria-label={t('defaultImageCount')} value={value.n} disabled={disabled} onChange={event => { void write('n', Number(event.target.value)) }}>
          {Array.from({ length: 10 }, (_, index) => index + 1).map(count => <option key={count} value={count}>{count}</option>)}
        </select>
      </Control>
      <Control label={t('defaultSize')}>
        <input aria-label={t('defaultSize')} aria-describedby={sizeHintId} list={sizesId} value={sizeDraft} disabled={disabled}
          onChange={event => { setSizeDraft(event.target.value) }} onBlur={saveSize}
          onKeyDown={event => { if (event.key === 'Enter') { event.preventDefault(); saveSize() } }} />
        <datalist id={sizesId}>{IMAGE_SIZES.map(size => <option key={size} value={size} />)}</datalist>
      </Control>
      <p className={classes.imageHint} id={sizeHintId}>{t('imageSizeHint')}</p>
      {!supportsImageSize(value.model, value.size) && <p className={classes.imageHint} role="alert">{t('invalidImageSize')}</p>}
      <Control label={t('defaultQuality')}>
        <select aria-label={t('defaultQuality')} value={value.quality} disabled={disabled} onChange={event => { void write('quality', event.target.value) }}>
          <option value="auto">{t('automatic')}</option><option value="low">{t('low')}</option><option value="medium">{t('medium')}</option><option value="high">{t('high')}</option>
          <option value="xhigh" disabled={!supportsImageQuality(value.model, 'xhigh')}>{t('xhigh')}</option>
          <option value="max" disabled={!supportsImageQuality(value.model, 'max')}>{t('maxQuality')}</option>
        </select>
      </Control>
      {!supportsImageQuality(value.model, value.quality) && <p className={classes.imageHint} role="alert">{t('invalidImageQuality')}</p>}
      <Control label={t('defaultBackground')}>
        <select aria-label={t('defaultBackground')} value={value.background} disabled={disabled} onChange={event => { void write('background', event.target.value) }}>
          <option value="auto">{t('automatic')}</option><option value="opaque">{t('opaque')}</option><option value="transparent">{t('transparent')}</option>
        </select>
      </Control>
    </div>
  )
}

function Switch({
  label,
  checked,
  disabled,
  onChange,
}: {
  label: string
  checked: boolean
  disabled: boolean
  onChange: (value: boolean) => void
}): ReactNode {
  return (
    <label className={classes.switchToggle} title={label}>
      <input
        type="checkbox"
        aria-label={label}
        checked={checked}
        disabled={disabled}
        onChange={(event: ChangeEvent<HTMLInputElement>) => { onChange(event.target.checked) }}
      />
      <span className={classes.switchSlider} />
    </label>
  )
}

function Control({ label, children }: { label: string; children: ReactNode }): ReactNode {
  return (
    <div className={classes.formRow}>
      <span className={classes.formLabel}>{label}</span>
      <div className={classes.formField}>{children}</div>
    </div>
  )
}

function useScope<T>(scope: ConfigForm<T>): ConfigFormSnapshot<T> {
  const subscribe = useCallback((listener: () => void) => scope.subscribe(listener), [scope])
  const getSnapshot = useCallback(() => scope.getSnapshot(), [scope])
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot)
}

function writer<T>(
  scope: ConfigForm<T>,
  onError: (message: string | null) => void,
  t: CodexCapabilitySettingsProps['t'],
): (field: string, value: unknown) => Promise<void> {
  return async (field, value) => {
    onError(null)
    try {
      if (await scope.set(field, value) === false) onError(t('writeFailed'))
    } catch (error) { onError(messageOf(error, t('writeFailed'))) }
  }
}

function localDate(value: string): string {
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString()
}

function titleCase(value: string): string {
  return value.length === 0 ? value : value[0]?.toUpperCase() + value.slice(1)
}

function messageOf(error: unknown, fallback: string): string {
  if (error instanceof Error && error.message.length > 0) return error.message
  return fallback
}

function quotaTone(percent: number): 'error' | 'warning' | 'normal' {
  if (percent < 30) return 'error'
  if (percent <= 60) return 'warning'
  return 'normal'
}
