#!/usr/bin/env node
/** Packaged-artifact smoke: exported Host modules, browser bundle, and patch rows. */
import { execFileSync } from 'node:child_process'
import { access, mkdir, mkdtemp, readFile, rm, symlink } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import semver from 'semver'
import { DSH_BASELINE, DSH_SOURCE_VERSION, DSH_VERIFY_VERSION, DSH_EXPERIMENTAL_PEER_RANGE, resolvedDshPackages } from './dsh-compatibility.mjs'

const CODEX_COMPACTION_DSH_RANGE = DSH_EXPERIMENTAL_PEER_RANGE
const EXPERIMENTAL_DSH_PEERS = [
  '@deepseek-ai/dsh-compaction',
  '@deepseek-ai/dsh-compaction-basic',
  '@deepseek-ai/dsh-token-meter',
]
const PI_AI_VERSION = '1.3.0'
const EXACT_SUPPORT_PACKAGES = {
  '@deepseek-ai/cordis': '4.1.0',
  '@deepseek-ai/schemastery': '3.19.0',
}
const RETIRED_DSH_PACKAGES = [
  '@deepseek-ai/dsh-client-runtime',
  '@deepseek-ai/dsh-host-apiproxy',
  '@deepseek-ai/dsh-invariants',
]
const SEMVER_OPTIONS = { includePrerelease: true }
const sourceRoot = resolve(import.meta.dirname, '..')
const temporary = await mkdtemp(resolve(tmpdir(), 'dsh-codex-auth-package-smoke-'))
try {
  const output = execFileSync('npm', [
    'pack', '--json', '--ignore-scripts', '--pack-destination', temporary,
  ], {
    cwd: sourceRoot,
    encoding: 'utf8',
    env: { ...process.env, npm_config_ignore_scripts: 'true' },
  })
  const jsonStart = output.lastIndexOf('\n[')
  const packed = JSON.parse(output.slice(jsonStart < 0 ? 0 : jsonStart + 1))
  const filename = packed?.[0]?.filename
  if (typeof filename !== 'string') throw new Error('package smoke: npm pack returned no artifact')
  const packedPaths = new Set((packed?.[0]?.files ?? []).map(file => file.path))
  execFileSync('tar', ['-xzf', resolve(temporary, filename), '-C', temporary])

  const packageRoot = resolve(temporary, 'package')
  const manifest = JSON.parse(await readFile(resolve(packageRoot, 'package.json'), 'utf8'))
  const changelog = await readFile(resolve(packageRoot, 'CHANGELOG.md'), 'utf8')
  if (!changelog.includes(`## [${String(manifest.version)}]`)) {
    throw new Error(`package smoke: CHANGELOG.md lacks release ${String(manifest.version)}`)
  }
  const requiredDocumentation = [
    'docs/codex-model-policy.md',
    'docs/gpt-image-2.5-compatibility.md',
    'docs/design.md',
    'docs/adr/0003-isolate-experimental-codex-compaction.md',
    'docs/adr/0004-restore-native-checkpoints-with-request-markers.md',
    'docs/adr/0005-create-dual-checkpoints-inside-basic-manual-transactions.md',
    'docs/adr/0006-preserve-turn-continuity-during-automatic-compaction.md',
    'docs/adr/0007-preserve-dual-checkpoints-across-session-lifecycles.md',
    'docs/adr/0008-fail-closed-account-rpc-on-alpha5.md',
  ]
  for (const documentation of requiredDocumentation) {
    if (!packedPaths.has(documentation)) {
      throw new Error(`package smoke: npm manifest lacks ${documentation}`)
    }
    await access(resolve(packageRoot, documentation))
  }
  for (const path of packedPaths) {
    if (path.startsWith('src/')
      || path.startsWith('tests/')
      || path.startsWith('scripts/')
      || path.startsWith('docs/research/')) {
      throw new Error(`package smoke: forbidden source-only path ${path}`)
    }
  }

  // Keep the packed module outside the repository and expose only dependencies
  // declared for package consumers. An undeclared, deep, or dev-only import can
  // no longer resolve accidentally through this checkout's parent node_modules.
  const isolatedNodeModules = resolve(temporary, 'node_modules')
  await mkdir(isolatedNodeModules, { recursive: true })
  const consumerDependencies = {
    ...manifest.dependencies,
    ...manifest.peerDependencies,
  }
  for (const dependency of Object.keys(consumerDependencies)) {
    const installed = resolve(sourceRoot, 'node_modules', dependency)
    await access(installed)
    const linked = resolve(isolatedNodeModules, dependency)
    await mkdir(dirname(linked), { recursive: true })
    await symlink(installed, linked, 'junction')
  }

  for (const section of ['peerDependencies', 'devDependencies']) {
    const required = section === 'peerDependencies'
      ? DSH_BASELINE
      : DSH_VERIFY_VERSION
    const entries = Object.entries(manifest[section] ?? {})
      .filter(([name]) => name.startsWith('@deepseek-ai/dsh-')
        && (section !== 'peerDependencies'
          || !EXPERIMENTAL_DSH_PEERS.includes(name)))
    if (entries.length === 0) throw new Error(`package smoke: ${section} declares no DSH packages`)
    for (const [name, range] of entries) {
      const parsed = semver.validRange(String(range), SEMVER_OPTIONS)
      const minimum = parsed === null ? null : semver.minVersion(parsed, SEMVER_OPTIONS)
      if (parsed === null
        || minimum === null
        || !semver.satisfies(required, parsed, SEMVER_OPTIONS)
        || (section === 'peerDependencies' && !semver.satisfies(DSH_SOURCE_VERSION, parsed))
        || semver.lt(minimum, required)) {
        throw new Error(`package smoke: ${section}.${name} must accept ${required} and exclude earlier versions`)
      }
    }
  }
  for (const name of EXPERIMENTAL_DSH_PEERS) {
    for (const section of ['peerDependencies', 'devDependencies']) {
      if (manifest[section]?.[name] !== (section === 'peerDependencies' ? DSH_EXPERIMENTAL_PEER_RANGE : DSH_VERIFY_VERSION)) {
        throw new Error(
          `package smoke: ${section}.${name} must declare the verified ${CODEX_COMPACTION_DSH_RANGE} graph`,
        )
      }
    }
    if (manifest.peerDependenciesMeta?.[name]?.optional !== true) {
      throw new Error(`package smoke: ${name} must remain an optional peer`)
    }
  }
  const piPeerRange = semver.validRange(
    String(manifest.peerDependencies?.['@earendil-works/pi-ai'] ?? ''),
    SEMVER_OPTIONS,
  )
  const piPeerMinimum = piPeerRange === null
    ? null
    : semver.minVersion(piPeerRange, SEMVER_OPTIONS)
  if (piPeerRange === null
    || piPeerMinimum === null
    || !semver.satisfies(PI_AI_VERSION, piPeerRange, SEMVER_OPTIONS)
    || semver.lt(piPeerMinimum, PI_AI_VERSION)) {
    throw new Error(`package smoke: pi-ai peer range must start at ${PI_AI_VERSION}`)
  }
  if (manifest.devDependencies?.['@earendil-works/pi-ai'] !== PI_AI_VERSION) {
    throw new Error(`package smoke: devDependencies must pin pi-ai to ${PI_AI_VERSION}`)
  }
  for (const [name, version] of Object.entries(EXACT_SUPPORT_PACKAGES)) {
    const peerRange = semver.validRange(String(manifest.peerDependencies?.[name] ?? ''), SEMVER_OPTIONS)
    if (peerRange === null || !semver.satisfies(version, peerRange, SEMVER_OPTIONS)) {
      throw new Error(`package smoke: peerDependencies.${name} must accept ${version}`)
    }
    if (manifest.devDependencies?.[name] !== version) {
      throw new Error(`package smoke: devDependencies.${name} must pin ${version}`)
    }
  }
  for (const name of RETIRED_DSH_PACKAGES) {
    if (manifest.peerDependencies?.[name] !== undefined
      || manifest.devDependencies?.[name] !== undefined
      || manifest.dsh?.client?.inject?.includes(name)) {
      throw new Error(`package smoke: retired DSH package remains declared: ${name}`)
    }
  }
  const lockfile = await readFile(resolve(sourceRoot, 'pnpm-lock.yaml'), 'utf8')
  const piAiResolutions = new Set([...lockfile.matchAll(
    /^ {2}['"]@earendil-works\/pi-ai@([^('"\s:]+).*['"]:\s*$/gmu,
  )].map(([, version]) => version))
  const snapshots = lockfile.split('\nsnapshots:\n', 2)[1] ?? ''
  const piAiSnapshotIdentities = [...snapshots.matchAll(
    /^ {2}['"](@earendil-works\/pi-ai@[^'"]+)['"]:\s*$/gmu,
  )].map(([, identity]) => identity)
  if (piAiResolutions.size !== 1
    || !piAiResolutions.has(PI_AI_VERSION)
    || piAiSnapshotIdentities.length !== 1) {
    throw new Error(
      `package smoke: pnpm-lock.yaml must contain one pi-ai ${PI_AI_VERSION} snapshot; found ${piAiSnapshotIdentities.join(', ') || 'none'}`,
    )
  }
  const dshResolutions = resolvedDshPackages(lockfile)
  if (dshResolutions.length === 0) {
    throw new Error('package smoke: pnpm-lock.yaml contains no resolved DSH package entries')
  }
  const mixedDsh = dshResolutions.filter(({ version }) => version !== DSH_VERIFY_VERSION)
  if (mixedDsh.length > 0) {
    throw new Error(
      `package smoke: pnpm-lock.yaml mixes the verified DSH graph: ${mixedDsh.map(({ name, version }) => `${name}@${version}`).join(', ')}`,
    )
  }
  const declaredDshNames = new Set(['peerDependencies', 'devDependencies']
    .flatMap(section => Object.keys(manifest[section] ?? {}))
    .filter(name => name.startsWith('@deepseek-ai/dsh-')))
  const highestDeclaredDshVersions = new Map()
  for (const { name, version } of dshResolutions) {
    if (!declaredDshNames.has(name) || semver.valid(version) === null) continue
    const current = highestDeclaredDshVersions.get(name)
    if (current === undefined || semver.gt(version, current)) highestDeclaredDshVersions.set(name, version)
  }
  const stale = [...declaredDshNames]
    .filter(name => !highestDeclaredDshVersions.has(name)
      || highestDeclaredDshVersions.get(name) !== DSH_VERIFY_VERSION)
  if (stale.length > 0) {
    throw new Error(
      `package smoke: pnpm-lock.yaml resolves declared DSH below ${CODEX_COMPACTION_DSH_RANGE}: ${stale.join(', ')}`,
    )
  }
  const hostExports = ['.', './search', './image', './compaction']
  for (const key of hostExports) {
    const target = manifest.exports?.[key]?.default
    const types = manifest.exports?.[key]?.types
    if (typeof target !== 'string' || typeof types !== 'string') {
      throw new Error(`package smoke: incomplete export ${key}`)
    }
    const absolute = resolve(packageRoot, target)
    await access(absolute)
    await access(resolve(packageRoot, types))
    const loaded = await import(pathToFileURL(absolute).href)
    if (typeof loaded.apply !== 'function') throw new Error(`package smoke: ${key} has no apply export`)
    if (key === '.') {
      const defaults = loaded.Config({})
      const configured = loaded.Config({ excludedModelIds: ['gpt-5.3-codex-spark'] })
      if (JSON.stringify(defaults.excludedModelIds.get()) !== '[]'
        || JSON.stringify(configured.excludedModelIds.get()) !== '["gpt-5.3-codex-spark"]') {
        throw new Error('package smoke: excludedModelIds must be a live, default-empty string array')
      }
    }
  }
  const compactionTarget = manifest.exports?.['./compaction']?.default
  const compaction = await import(pathToFileURL(resolve(packageRoot, compactionTarget)).href)
  if (typeof compaction.CodexCompactionEngine !== 'function') {
    throw new Error('package smoke: compaction export has no CodexCompactionEngine')
  }
  if (compaction.CODEX_COMPACTION_COMPATIBILITY?.dsh !== CODEX_COMPACTION_DSH_RANGE
    || compaction.CODEX_COMPACTION_COMPATIBILITY?.piAi !== PI_AI_VERSION) {
    throw new Error('package smoke: compaction export does not advertise the verified runtime graphs')
  }
  compaction.assertCodexCompactionCompatibility()

  const checkpointExport = manifest.exports?.['./native-checkpoint']
  if (typeof checkpointExport?.default !== 'string'
    || typeof checkpointExport?.types !== 'string') {
    throw new Error('package smoke: incomplete native-checkpoint export')
  }
  const checkpointTarget = resolve(packageRoot, checkpointExport.default)
  await access(checkpointTarget)
  await access(resolve(packageRoot, checkpointExport.types))
  const checkpoint = await import(pathToFileURL(checkpointTarget).href)
  if (checkpoint.CODEX_NATIVE_REPLAY_COMPATIBILITY?.dsh !== CODEX_COMPACTION_DSH_RANGE
    || checkpoint.CODEX_NATIVE_REPLAY_COMPATIBILITY?.piAi !== PI_AI_VERSION
    || typeof checkpoint.encodeCodexNativeCheckpoint !== 'function'
    || typeof checkpoint.decodeCodexNativeCheckpoint !== 'function'
    || checkpoint.isCodexNativeReplayRuntimeCompatible() !== true) {
    throw new Error('package smoke: native-checkpoint export lacks its verified codec/replay contract')
  }

  const presetRoot = resolve(packageRoot, 'examples/agent-presets/codex-portable')
  const presetMetadata = await readFile(resolve(presetRoot, 'preset.yml'), 'utf8')
  if (!presetMetadata.includes('Dual Checkpoint')) {
    throw new Error('package smoke: custom preset does not describe Dual Checkpoint compaction')
  }
  const preset = await readFile(resolve(presetRoot, 'agent.cordis.yml'), 'utf8')
  if ((preset.match(/name: 'dsh-codex-auth\/compaction'/gu) ?? []).length !== 1) {
    throw new Error('package smoke: custom preset must select exactly one Codex compaction Adapter')
  }
  for (const row of [
    "name: '@deepseek-ai/dsh-command-compact'",
    "name: '@deepseek-ai/dsh-compaction-tool-result-pruner'",
  ]) {
    if (!preset.includes(row)) throw new Error(`package smoke: custom preset lacks ${row}`)
  }
  if (preset.includes("name: '@deepseek-ai/dsh-compaction-basic'")) {
    throw new Error('package smoke: custom preset also activates compaction-basic')
  }

  const clientTarget = manifest.exports?.['./client']?.default
  const clientTypes = manifest.exports?.['./client']?.types
  if (typeof clientTarget !== 'string' || typeof clientTypes !== 'string') {
    throw new Error('package smoke: incomplete client export')
  }
  await access(resolve(packageRoot, clientTypes))
  const client = await readFile(resolve(packageRoot, clientTarget), 'utf8')
  for (const marker of ['window.__ModuleLoader__.load', 'generate_image', 'list_images', 'codex-search', 'codex-image']) {
    if (!client.includes(marker)) throw new Error(`package smoke: client bundle lacks ${marker}`)
  }
  if (client.includes('require("@deepseek-ai/dsh-client-ui-attachment")')) {
    throw new Error('package smoke: client bundle imports private values from the attachment plugin browser face')
  }

  const patch = await readFile(resolve(packageRoot, manifest.dsh?.bundle?.patch ?? ''), 'utf8')
  for (const row of ['dsh-codex-auth', 'dsh-codex-auth/search', 'dsh-codex-auth/image']) {
    if (!patch.includes(`name: '${row}'`)) throw new Error(`package smoke: patch lacks ${row}`)
  }
  if (!patch.includes('searchProvider: codex')) {
    throw new Error('package smoke: patch does not select Codex globally')
  }
  if (patch.includes('dsh-codex-auth/compaction')) {
    throw new Error('package smoke: default bundle must not activate experimental compaction')
  }

  console.log(`package smoke: ${filename} exposes Host modules, Native replay codec, Dual Checkpoint example, design/ADRs, client, types, and unchanged bundle activation`)
} finally {
  await rm(temporary, { recursive: true, force: true })
}
