/** @vitest-environment jsdom */
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import type { ComponentType } from 'react'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import type { ConfigForm, ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client'
import { PartialArguments } from '@deepseek-ai/dsh-util-values'
import type { ToolCallBlock } from '@deepseek-ai/dsh-client-ui-chat/client'
import type { CodexImageSettings } from '../src/image.ts'
import type { CodexSearchSettings } from '../src/search.ts'
import type { CodexAuthRpcClient, CodexAuthStatusView, CodexUsageView } from '../src/rpc-contract.ts'
import {
  CodexCapabilitySettings, CodexImageToolView, apply, inject,
} from '../src/client/index.ts'
import { en, zh } from '../src/client/locales.ts'
import { afterEach, describe, expect, it, vi } from 'vitest'

vi.mock('@deepseek-ai/dsh-client-ui-attachment', () => ({
  ImageGallery: ({ images }: { images: Array<{ attachment: ImageAttachmentRef }> }) => (
    <div>{images.map(({ attachment }) => <img key={String(attachment.attachmentId)} alt={attachment.name ?? 'Generated image'} />)}</div>
  ),
}))

const LLM = { longContextEnabled: false }

const SEARCH: CodexSearchSettings = {
  enabled: true,
  mode: 'live',
  contextSize: 'medium',
  fallbackModel: 'gpt-5.4',
  maxOutputTokens: 2048,
}
const IMAGE: CodexImageSettings = {
  enabled: true,
  model: 'gpt-image-2',
  n: 1,
  size: 'auto',
  quality: 'auto',
  background: 'auto',
}

function fakeScope<T>(
  initial: T,
  status: ConfigFormSnapshot<T>['status'] = 'ready',
  beforeSet?: () => Promise<void>,
): { scope: ConfigForm<T>; set: ReturnType<typeof vi.fn> } {
  let snapshot: ConfigFormSnapshot<T> = {
    status,
    value: initial,
    base: initial,
    user: {},
    revision: 1,
    writable: true,
  }
  const listeners = new Set<() => void>()
  const set = vi.fn(async (field: string, value: unknown) => {
    await beforeSet?.()
    snapshot = { ...snapshot, value: { ...(snapshot.value ?? initial), [field]: value } }
    for (const listener of listeners) listener()
    return true
  })
  const scope = {
    getSnapshot() {
      if (this !== scope) throw new Error('getSnapshot lost its ConfigForm receiver')
      return snapshot
    },
    subscribe(listener: () => void) {
      if (this !== scope) throw new Error('subscribe lost its ConfigForm receiver')
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    },
    set,
    unset: vi.fn(async () => true),
    mutate: vi.fn(async () => true),
  } satisfies ConfigForm<T>
  return { set, scope }
}

function authStatus(overrides: Partial<CodexAuthStatusView>): CodexAuthStatusView {
  return {
    available: true,
    configured: true,
    credentialRef: '~/.codex/auth.json',
    authFileExists: true,
    ...overrides,
  }
}

function rpc(status: CodexAuthStatusView, usage: CodexUsageView = {}): CodexAuthRpcClient {
  return {
    fastMode: vi.fn(async () => ({ ok: true as const, value: { fastMode: { enabled: false, source: 'profile' as const } } })),
    status: vi.fn(async () => ({ ok: true as const, value: { status } })),
    usage: vi.fn(async () => ({ ok: true as const, value: { usage } })),
    login: vi.fn(async () => ({ ok: true as const, value: { started: true } })),
  }
}

const t = (key: keyof typeof en): string => en[key]
const subscribe = (): (() => void) => () => {}

afterEach(() => cleanup())

describe('Codex Capability Bundle settings', () => {
  it('toggles Fast mode through the live LLM form with its subscription usage warning', async () => {
    const llm = fakeScope({ ...LLM, fastModeEnabled: false })
    render(<CodexCapabilitySettings rpc={rpc(authStatus({}))} t={t} subscribe={subscribe}
      llmScope={llm.scope} searchScope={fakeScope(SEARCH).scope} imageScope={fakeScope(IMAGE).scope} />)
    const toggle = screen.getByLabelText('Enable Fast mode') as HTMLInputElement
    expect(toggle.checked).toBe(false)
    expect(screen.getByText(/subscription.*2\.5/i)).toBeTruthy()
    fireEvent.click(toggle)
    await waitFor(() => expect(llm.set).toHaveBeenCalledWith('fastModeEnabled', true))
    expect(toggle.checked).toBe(true)
    fireEvent.click(toggle)
    await waitFor(() => expect(llm.set).toHaveBeenCalledWith('fastModeEnabled', false))
  })

  it('blocks editing until a pending exclusion save settles, then permits clearing the saved list', async () => {
    const pending = Promise.withResolvers<void>()
    const llm = fakeScope({ ...LLM, excludedModelIds: [] as string[] }, 'ready', () => pending.promise)
    render(<CodexCapabilitySettings rpc={rpc(authStatus({}))} t={t} subscribe={subscribe}
      llmScope={llm.scope} searchScope={fakeScope(SEARCH).scope} imageScope={fakeScope(IMAGE).scope} />)
    const input = screen.getByLabelText('Excluded model IDs') as HTMLInputElement
    fireEvent.change(input, { target: { value: 'gpt-5.3-codex-spark' } })
    fireEvent.keyDown(input, { key: 'Enter' })
    expect(input.disabled).toBe(true)
    fireEvent.blur(input)
    expect(llm.set).toHaveBeenCalledTimes(1)
    pending.resolve()
    await waitFor(() => expect(input.disabled).toBe(false))
    expect(input.value).toBe('gpt-5.3-codex-spark')
    fireEvent.change(input, { target: { value: '' } })
    fireEvent.blur(input)
    await waitFor(() => expect(llm.set).toHaveBeenLastCalledWith('excludedModelIds', []))
    await waitFor(() => expect(input.disabled).toBe(false))
    expect(input.value).toBe('')
  })

  it('saves exact model exclusions on blur or Enter, deduplicates input, and clears to an empty list', async () => {
    const llm = fakeScope({ ...LLM, excludedModelIds: ['gpt-5.4'] })
    render(<CodexCapabilitySettings rpc={rpc(authStatus({}))} t={t} subscribe={subscribe}
      llmScope={llm.scope} searchScope={fakeScope(SEARCH).scope} imageScope={fakeScope(IMAGE).scope} />)
    const input = screen.getByLabelText('Excluded model IDs') as HTMLInputElement
    expect(input.value).toBe('gpt-5.4')
    expect(screen.getByText(/catalog visibility, not request permissions/)).toBeTruthy()
    fireEvent.change(input, { target: { value: ' gpt-5.3-codex-spark, unknown, gpt-5.3-codex-spark, ' } })
    expect(llm.set).not.toHaveBeenCalled()
    fireEvent.blur(input)
    await waitFor(() => expect(llm.set).toHaveBeenCalledWith('excludedModelIds', ['gpt-5.3-codex-spark', 'unknown']))
    fireEvent.change(input, { target: { value: ' ' } })
    fireEvent.keyDown(input, { key: 'Enter' })
    await waitFor(() => expect(llm.set).toHaveBeenCalledWith('excludedModelIds', []))
  })

  it('resets exclusion drafts when switching profiles and surfaces save failures', async () => {
    const first = fakeScope({ ...LLM, excludedModelIds: ['gpt-5.4'] })
    const second = fakeScope({ ...LLM, excludedModelIds: ['gpt-6-sol'] })
    const props = { rpc: rpc(authStatus({})), t, subscribe, searchScope: fakeScope(SEARCH).scope, imageScope: fakeScope(IMAGE).scope }
    const { rerender } = render(<CodexCapabilitySettings {...props} llmScope={first.scope} />)
    fireEvent.change(screen.getByLabelText('Excluded model IDs'), { target: { value: 'unsaved' } })
    rerender(<CodexCapabilitySettings {...props} llmScope={second.scope} />)
    expect((screen.getByLabelText('Excluded model IDs') as HTMLInputElement).value).toBe('gpt-6-sol')
    second.set.mockRejectedValueOnce(new Error('Storage unavailable'))
    fireEvent.change(screen.getByLabelText('Excluded model IDs'), { target: { value: 'gpt-5.4' } })
    fireEvent.blur(screen.getByLabelText('Excluded model IDs'))
    expect(await screen.findByRole('alert')).toHaveProperty('textContent', 'Storage unavailable')
    second.set.mockResolvedValueOnce(false)
    fireEvent.change(screen.getByLabelText('Excluded model IDs'), { target: { value: 'unknown' } })
    fireEvent.blur(screen.getByLabelText('Excluded model IDs'))
    await waitFor(() => expect(screen.getByRole('alert')).toHaveProperty('textContent', en.writeFailed))
    expect(first.set).not.toHaveBeenCalled()
  })

  it('saves GPT Image 2.5 quality and custom dimensions while rejecting incomplete sizes', async () => {
    const image = fakeScope({ ...IMAGE, model: 'gpt-image-2.5-sunburst' })
    render(<CodexCapabilitySettings rpc={rpc(authStatus({ planType: 'plus' }))} t={t} subscribe={subscribe}
      llmScope={fakeScope(LLM).scope} searchScope={fakeScope(SEARCH).scope} imageScope={image.scope} />)
    await screen.findByText('Active')
    fireEvent.click(screen.getByRole('button', { name: 'Expand Image Creation settings' }))
    const modelOptions = (screen.getByRole('combobox', { name: 'Image model' }) as HTMLSelectElement).options
    expect(Array.from(modelOptions ?? [], option => option.value)).toContain('gpt-image-2.5-flare')
    fireEvent.change(screen.getByLabelText('Image model'), { target: { value: 'gpt-image-2.5-flare' } })
    await waitFor(() => expect(image.set).toHaveBeenCalledWith('model', 'gpt-image-2.5-flare'))
    fireEvent.change(screen.getByLabelText('Default quality'), { target: { value: 'max' } })
    await waitFor(() => expect(image.set).toHaveBeenCalledWith('quality', 'max'))
    const size = screen.getByLabelText('Default size')
    fireEvent.change(size, { target: { value: '1536x' } })
    fireEvent.blur(size)
    expect(image.set).not.toHaveBeenCalledWith('size', expect.anything())
    fireEvent.change(size, { target: { value: '1536x864' } })
    fireEvent.blur(size)
    await waitFor(() => expect(image.set).toHaveBeenCalledWith('size', '1536x864'))
    fireEvent.change(screen.getByLabelText('Image model'), { target: { value: 'gpt-image-2' } })
    await waitFor(() => expect(image.set).toHaveBeenCalledWith('model', 'gpt-image-2'))
    expect((screen.getByRole('option', { name: 'Maximum' }) as HTMLOptionElement).disabled).toBe(true)
  })

  it('renders Login, LLM Context, Search, and Image Creation as one live four-card section', async () => {
    const llm = fakeScope(LLM)
    const search = fakeScope(SEARCH)
    const image = fakeScope(IMAGE)
    render(<CodexCapabilitySettings
      rpc={rpc(
        authStatus({ credentialRef: '/Users/alice/.codex/auth.json', accountId: 'acct-1', planType: 'plus' }),
        { weeklyRemainingPercent: 49, weeklyResetAt: '2026-08-20T12:00:00.000Z' },
      )}
      t={t}
      subscribe={subscribe}
      llmScope={llm.scope}
      searchScope={search.scope}
      imageScope={image.scope}
    />)

    expect(await screen.findByText('Active')).toBeTruthy()
    expect(screen.getByRole('heading', { name: 'Login' })).toBeTruthy()
    expect(screen.getByRole('heading', { name: 'LLM Context' })).toBeTruthy()
    expect(screen.getByRole('heading', { name: 'Web Search' })).toBeTruthy()
    expect(screen.getByRole('heading', { name: 'Image Creation' })).toBeTruthy()
    // The login block only surfaces plan, remaining quota, and weekly reset.
    expect(screen.getByText('Plus plan')).toBeTruthy()
    expect(screen.getByText('49%')).toBeTruthy()
    expect(screen.getByText('Remaining quota')).toBeTruthy()
    expect(screen.getByText('Weekly limit resets')).toBeTruthy()
    expect(screen.queryByText('acct-1')).toBeNull()
    expect(screen.queryByText('/Users/alice/.codex/auth.json')).toBeNull()
    expect(screen.getByText(/no token value is ever sent to the Web client/i)).toBeTruthy()

    fireEvent.click(screen.getByLabelText('Enable long context'))
    await waitFor(() => expect(llm.set).toHaveBeenCalledWith('longContextEnabled', true))

    const expandSearch = screen.getByRole('button', { name: 'Expand Web Search settings' })
    const expandImage = screen.getByRole('button', { name: 'Expand Image Creation settings' })
    expect(expandSearch.getAttribute('aria-expanded')).toBe('false')
    expect(expandImage.getAttribute('aria-expanded')).toBe('false')
    fireEvent.click(expandSearch)
    fireEvent.click(expandImage)
    expect(screen.getByRole('button', { name: 'Collapse Web Search settings' }).getAttribute('aria-expanded')).toBe('true')
    expect(screen.getByRole('button', { name: 'Collapse Image Creation settings' }).getAttribute('aria-expanded')).toBe('true')

    fireEvent.change(screen.getByLabelText('Search mode'), { target: { value: 'cached' } })
    await waitFor(() => expect(search.set).toHaveBeenCalledWith('mode', 'cached'))
    fireEvent.change(screen.getByLabelText('Default image count'), { target: { value: '3' } })
    await waitFor(() => expect(image.set).toHaveBeenCalledWith('n', 3))
  })

  it('announces loading settings while keeping skeleton rows decorative', async () => {
    const { container } = render(<CodexCapabilitySettings
      rpc={rpc(authStatus({ planType: 'plus' }))}
      t={t}
      subscribe={subscribe}
      llmScope={fakeScope(LLM, 'loading').scope}
      searchScope={fakeScope(SEARCH, 'loading').scope}
      imageScope={fakeScope(IMAGE, 'loading').scope}
    />)

    expect(await screen.findByText('Active')).toBeTruthy()
    expect(screen.getAllByText('Loading settings…')).toHaveLength(3)
    const visibleBusyRegions = screen.getAllByRole('status')
      .filter(region => region.getAttribute('aria-busy') === 'true')
    expect(visibleBusyRegions).toHaveLength(1)
    expect(container.querySelectorAll('[aria-busy="true"]')).toHaveLength(3)
    expect(container.querySelectorAll('[aria-busy="true"] > div:not([aria-hidden="true"])')).toHaveLength(0)
  })

  it('identifies a known Free plan while leaving unknown plans backend-authoritative', async () => {
    const { rerender } = render(<CodexCapabilitySettings
      rpc={rpc(authStatus({ credentialRef: '/tmp/auth.json', accountId: 'acct-free', planType: 'free' }))}
      t={t}
      subscribe={subscribe}
      llmScope={fakeScope(LLM).scope}
      searchScope={fakeScope(SEARCH).scope}
      imageScope={fakeScope(IMAGE).scope}
    />)
    expect(await screen.findByText('Unavailable on Free plan')).toBeTruthy()
    expect((screen.getByLabelText('Enable Image Creation') as HTMLInputElement).disabled).toBe(true)

    rerender(<CodexCapabilitySettings
      rpc={rpc(authStatus({ credentialRef: '/tmp/auth.json' }))}
      t={t}
      subscribe={subscribe}
      llmScope={fakeScope(LLM).scope}
      searchScope={fakeScope(SEARCH).scope}
      imageScope={fakeScope(IMAGE).scope}
    />)
    // A configured non-Free plan carries no badge on either capability card.
    expect(await screen.findByText('Unknown plan')).toBeTruthy()
    expect(screen.queryByText('Entitlement checked on use')).toBeNull()
    expect(screen.queryByText('Deployment-wide provider')).toBeNull()

    rerender(<CodexCapabilitySettings
      rpc={rpc(authStatus({ configured: false, authFileExists: false }))}
      t={t}
      subscribe={subscribe}
      llmScope={fakeScope(LLM).scope}
      searchScope={fakeScope(SEARCH).scope}
      imageScope={fakeScope(IMAGE).scope}
    />)
    expect((await screen.findAllByText('Available after login')).length).toBe(2)
    expect((screen.getByLabelText('Enable Web Search') as HTMLInputElement).disabled).toBe(true)
    expect((screen.getByLabelText('Enable Image Creation') as HTMLInputElement).disabled).toBe(true)
  })
})

describe('Codex Image Creation tool view', () => {
  it('renders only generated images after a successful call', async () => {
    const attachment: ImageAttachmentRef = {
      attachmentId: 'att-1' as ImageAttachmentRef['attachmentId'],
      mediaType: 'image/png',
      bytes: 68,
      width: 1,
      height: 1,
      name: 'generated.png',
    }
    const block: ToolCallBlock = {
      kind: 'tool-result',
      seq: 3,
      time: 30,
      callId: 'call-1',
      name: 'generate_image',
      args: PartialArguments.fromObject({ prompt: 'fox' }),
      call: { name: 'generate_image', argsRaw: '{"prompt":"fox"}' },
      callTime: 10,
      content: [{ type: 'image', attachment }],
      isError: false,
      meta: {
        operation: 'generate',
        images: [{ handle: 'image:att-1', attachment, origin: 'generated' }],
        references: [],
        warnings: [{ index: 1, code: 'IMAGE_MEDIA_INVALID', message: 'One item was invalid.' }],
      },
      subCalls: [],
    }
    const loadImage = vi.fn(async () => 'data:image/png;base64,iVBORw0KGgo=')

    const { container } = render(<CodexImageToolView block={block} loadImage={loadImage} />)

    expect(await screen.findByRole('img', { name: 'generated.png' })).toBeTruthy()
    expect(container.textContent).toBe('')
    expect(screen.queryByText('image:att-1')).toBeNull()
    expect(screen.queryByRole('button', { name: 'Save to workspace' })).toBeNull()
  })

  it('shows a stable in-progress state before a tool result lands', () => {
    const block: ToolCallBlock = {
      callId: 'call-1',
      name: 'generate_image',
      phase: 'start',
      args: PartialArguments.fromObject({ prompt: 'fox' }),
      argsRaw: '{"prompt":"fox"}',
      turn: 1,
      step: 1,
      time: 10,
      subCalls: [],
    }
    const { rerender } = render(<CodexImageToolView block={block} loadImage={vi.fn()} />)
    expect(screen.getByText('Creating images…')).toBeTruthy()
    rerender(<CodexImageToolView block={block} loadImage={vi.fn()} t={key => zh[key]} />)
    expect(screen.getByText('正在创作图片…')).toBeTruthy()
  })
})

describe('client plugin registration', () => {
  it('registers settings, account limits in the composer dock, and both image tools', async () => {
    const registered: Array<Record<string, unknown>> = []
    const scopes = new Map<string, ConfigForm<unknown>>([
      ['llm-codex-auth', fakeScope(LLM).scope],
      ['codex-search', fakeScope(SEARCH).scope],
      ['codex-image', fakeScope(IMAGE).scope],
    ])
    const binding = { ctx: {} }
    const initializeDraft = vi.fn(() => 'applied')
    const focusDraft = vi.fn()
    const sessions = { binding: vi.fn(() => binding) }
    const connection = { isLoopback: true, rpc: { call: vi.fn(async () => ({ ok: true, value: { usage: { weeklyRemainingPercent: 49, fiveHourRemainingPercent: 88 } } })) } }
    const ctx = {
      effect: (setup: () => unknown) => setup(),
      on: vi.fn(() => () => {}),
      get: (name: string) => name === 'connection' ? connection : undefined,
      sessions,
      uiConversation: { events: { register: vi.fn() } },
      conversation: { input: { requestDraftInitialization: initializeDraft, for: () => ({ focus: focusDraft }) } },
      locale: { register: vi.fn(() => () => {}), bind: vi.fn(() => t) },
      slots: {
        inject: (_name: string, setup: () => unknown) => setup(),
        register: (registration: Record<string, unknown>, component: unknown) => {
          registered.push({ ...registration, component })
          return () => {}
        },
      },
      configForms: { get: (entryId: string) => scopes.get(entryId) },
    }

    apply(ctx as never)

    expect(inject).toEqual(expect.arrayContaining(['remote', 'configForms', 'sessions']))
    expect(registered).toEqual(expect.arrayContaining([
      expect.objectContaining({ name: 'settings.section', id: 'codex-auth' }),
      expect.objectContaining({ name: 'conversation.composer.dock', id: 'codex-usage' }),
      expect.objectContaining({ name: 'tool.call.toolview', key: 'generate_image' }),
      expect.objectContaining({ name: 'conversation.chat.turnTail', id: 'codex-generated-images' }),
      expect.objectContaining({ name: 'conversation.composer.dock', id: 'codex-create-image' }),
      expect.objectContaining({ name: 'conversation.hero.options', id: 'codex-create-image' }),
      expect.objectContaining({ name: 'tool.call.toolview', key: 'list_images' }),
    ]))

    const tail = registered.find(item => item.id === 'codex-generated-images')!
    const tailActions = (tail.inject as (sessionId: string) => {
      editImage: (image: ImageAttachmentRef, prompt: string) => boolean
    })('session-a')
    const selectedImage: ImageAttachmentRef = {
      attachmentId: 'sha256:selected' as ImageAttachmentRef['attachmentId'],
      mediaType: 'image/png', bytes: 3, width: 1024, height: 1024,
    }
    expect(tailActions.editImage(selectedImage, 'Edit selected image')).toBe(true)
    expect(initializeDraft).toHaveBeenCalledWith(binding, {
      prompt: 'Edit selected image', whenDraftExists: 'append',
    })
    expect(focusDraft).toHaveBeenCalledTimes(1)
    initializeDraft.mockReturnValueOnce('blocked')
    expect(tailActions.editImage(selectedImage, 'Edit selected image')).toBe(false)
    expect(focusDraft).toHaveBeenCalledTimes(1)

    const footer = registered.find(item => item.id === 'codex-usage')!
    const Footer = footer.component as ComponentType<Record<string, unknown>>
    const footerProps = (footer.inject as () => Record<string, unknown>)()
    const mounted = render(<Footer {...footerProps} />)
    expect(await screen.findByText(/Codex.*5h 88%.*Week 49%/)).toBeTruthy()
    mounted.unmount()

    const ListImagesView = registered.find(item => item.key === 'list_images')?.component as ComponentType<{
      block: ToolCallBlock
      sessionId: string
      t: typeof t
    }>
    const listBlock: ToolCallBlock = {
      kind: 'tool-result',
      seq: 4,
      time: 40,
      callId: 'call-list',
      name: 'list_images',
      args: PartialArguments.EMPTY,
      call: { name: 'list_images', argsRaw: '{}' },
      callTime: 30,
      content: [],
      isError: false,
      meta: { operation: 'list', items: [], nextCursor: null },
      subCalls: [],
    }
    const listResult = render(<ListImagesView block={listBlock} sessionId="session-a" t={t} />)
    expect(listResult.container.firstElementChild).toBeNull()
  })
})
