/**
 * Codex-auth login plugin, host half. Mounts:
 *
 * - an LLM adapter owning the `openai-codex` provider route, wrapping the
 *   installed pi-ai codex provider (chatgpt.com/backend-api, Responses
 *   protocol) with the ChatGPT access token resolved live from the codex CLI's
 *   auth file;
 * - the `codexAuth` service: login status (value-free) and login-flow startup
 *   for the web surface.
 *
 * The credentials seam is deliberately untouched: it is single-provider by
 * design, and the codex token is not a key the harness should store or
 * describe — it lives in the codex CLI's own file, refreshed by this plugin
 * through the official OAuth endpoint.
 *
 * @module dsh-codex-auth
 */

import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/cordis-plugin-loader'
import z from '@deepseek-ai/schemastery'
import type {} from '@deepseek-ai/dsh-client-connection'
import type {} from '@deepseek-ai/dsh-commands'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import type { CredentialRef } from '@deepseek-ai/dsh-credentials'
import type {} from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-settings'
import type {} from '@deepseek-ai/dsh-api-session-controller'
import type { SessionId, SessionStore } from '@deepseek-ai/dsh-session'
import { sessionFastMode, sessionFastModeView, saveSessionFastMode } from './codex-session-fast-mode.ts'
import { DEFAULT_REFRESH_LEAD_MS, defaultAuthJsonPath } from './codex-auth.ts'
import {
  CODEX_ROUTE, CodexAuthAdapter, DEFAULT_REQUEST_TIMEOUT_MS, DEFAULT_TRANSPORT,
  DEFAULT_WEBSOCKET_CONNECT_TIMEOUT_MS,
} from './codex-auth-adapter.ts'
import type { CodexAuthTransport } from './codex-auth-adapter.ts'
import { CodexAuthService } from './codex-auth-service.ts'
import type { CodexLlmSettings } from './codex-context.ts'
import { liveValue, type LiveValue } from './volatile-config.ts'
import { installEnvHttpProxy } from './env-proxy.ts'
import { createCodexAuthCommand } from './auth-command.ts'
import {
  commandAccountMode, createLoopbackRpcGuard,
} from './loopback-rpc.ts'
import { registerAccountRoutes } from './account-routes.ts'
import { installForeignCheckpointProjection } from './foreign-checkpoint-projection.ts'
import { CODEX_AUTH_RPC_NAMESPACE, handleCodexAuthRpc } from './rpc.ts'

export const name = 'llm-codex-auth'
export const inject = ['llm']

/** Plugin configuration; every field has a default, so a bare row mounts the plugin. */
export interface Config {
  /** Whether this row owns the openai-codex LLM route; auth coordination remains available when false. */
  llmEnabled: boolean
  /** Codex auth file path; empty (default) resolves `$CODEX_HOME` or `~/.codex/auth.json`. */
  authJsonPath: string
  /** Credential reference advertised by the status card. */
  credentialRef: string
  /** Lead time before access-token expiry that triggers a refresh. */
  refreshLeadMs: number
  /** The codex CLI command used for login and version probing. */
  codexCommand: string
  /** Selector label for the provider route. */
  displayName: string
  /** Opt into model-specific long-context budgets for supported GPT-5.6 and GPT-6/6.1 models. */
  longContextEnabled: LiveValue<boolean>
  /** Opt into Fast processing for Codex LLM requests, with higher subscription usage. */
  fastModeEnabled?: LiveValue<boolean>
  /** Exact model IDs hidden from this profile's Codex catalog; empty preserves the catalog. */
  excludedModelIds?: LiveValue<string[]>
  /** Streaming transport for the route; SSE by default because the WebSocket upgrade is unreliable through common HTTP proxies. */
  transport: CodexAuthTransport
  /** WebSocket connect timeout in milliseconds; only used when `transport` is not `sse`; zero disables it. */
  websocketConnectTimeoutMs: number
  /** Request timeout in milliseconds (SSE response-header phase and WebSocket message idle); zero disables it. */
  timeoutMs: number
}

export const Config: z<Config> = z.object({
  llmEnabled: z.boolean().default(true),
  authJsonPath: z.string().default(''),
  credentialRef: z.string().default('CODEX_CHATGPT_TOKEN'),
  refreshLeadMs: z.number().min(0).default(DEFAULT_REFRESH_LEAD_MS),
  codexCommand: z.string().default('codex'),
  displayName: z.string().default('OpenAI Codex (chatgpt)'),
  longContextEnabled: z.boolean().default(false).volatile(),
  fastModeEnabled: z.boolean().default(false).volatile(),
  excludedModelIds: z.array(z.string()).default([]).volatile(),
  transport: z.union([z.const('auto'), z.const('sse'), z.const('websocket')]).default(DEFAULT_TRANSPORT),
  websocketConnectTimeoutMs: z.natural().default(DEFAULT_WEBSOCKET_CONNECT_TIMEOUT_MS),
  timeoutMs: z.natural().default(DEFAULT_REQUEST_TIMEOUT_MS),
}) as unknown as z<Config>

/** Mount the codex-auth adapter and service. */
export function apply(ctx: Context, config: Config): void {
  installForeignCheckpointProjection(ctx)
  // Without this, Node's fetch ignores the machine's HTTP proxy env and the
  // chatgpt backend is unreachable on proxied networks (connect timeout).
  installEnvHttpProxy((message) => { ctx.logger.warn(String(message)) })
  const credentialReference: CredentialRef = credentialRef(config.credentialRef)
  const authJsonPath = config.authJsonPath.length > 0 ? config.authJsonPath : defaultAuthJsonPath()
  const service = new CodexAuthService(ctx, {
    authJsonPath,
    codexCommand: config.codexCommand,
    credentialRef: credentialReference,
    refreshLeadMs: config.refreshLeadMs,
    fetchImpl: fetch,
  })
  ctx.inject(['commands'], commandCtx => {
    commandCtx.commands.register(createCodexAuthCommand(service, () => commandAccountMode(commandCtx.get('webServer'))))
  })
  const currentSettings = (): CodexLlmSettings => ({
    longContextEnabled: liveValue(config.longContextEnabled),
    fastModeEnabled: liveValue(config.fastModeEnabled ?? false),
    excludedModelIds: liveValue(config.excludedModelIds ?? []),
  })
  let announceModelPolicyChange = (): void => {}
  if (config.llmEnabled) {
    if (ctx.llm.listProviders().some(provider => provider.id === CODEX_ROUTE)) {
      throw new Error(
        'dsh-codex-auth cannot own the "openai-codex" route because another plugin already registered it; '
        + 'dsh-codex-auth and dsh-codex are mutually exclusive, so uninstall or disable one bundle',
      )
    }
    const adapter = new CodexAuthAdapter(ctx, {
      auth: service,
      authJsonPath,
      credentialRef: credentialReference,
      refreshLeadMs: config.refreshLeadMs,
      fetchImpl: fetch,
      displayName: config.displayName,
      settings: () => currentSettings(),
      fastModeForSession: id => id === undefined ? undefined : sessionFastMode((ctx.get('sessions') as unknown as SessionStore | undefined)?.get(id as SessionId)),
      transport: config.transport,
      websocketConnectTimeoutMs: config.websocketConnectTimeoutMs,
      timeoutMs: config.timeoutMs,
    })
    const registration = ctx.llm.registerAdapter([CODEX_ROUTE], adapter)
    announceModelPolicyChange = () => {
      adapter.replaceRouteGeneration()
      registration.replace([CODEX_ROUTE])
    }
  }
  ctx.inject(['settings'], settingsCtx => {
    settingsCtx.effect(() => settingsCtx.settings.configure({ auto: false }, ctx.fiber))
  })
  ctx.on('loader/volatile-update', announceModelPolicyChange)
  ctx.inject(['connection'], connectionCtx => {
    const guard = createLoopbackRpcGuard(
      () => connectionCtx.get('webServer')?.host,
      (endpoint, payload, signal) => handleCodexAuthRpc(service, endpoint, payload, signal, async (id, enabled) => {
        const sessions = ctx.get('sessions') as SessionStore | undefined
        if (sessions === undefined) throw new Error('Session store is unavailable')
        let session = sessions.get(id as SessionId)
        if (session === undefined) {
          const controller = ctx.get('sessionController')
          if (controller === undefined) throw new Error('Session controller is unavailable')
          const resolved = await controller.resolveAgent(id as SessionId)
          if ('error' in resolved) throw new Error('Session is unavailable for Fast mode')
          session = resolved.agent.session
        }
        if (enabled !== undefined) {
          saveSessionFastMode(session, enabled)
          if (!await sessions.flush(session)) throw new Error('Session Fast preference could not be persisted')
        }
        return sessionFastModeView(session, currentSettings().fastModeEnabled === true)
      }),
    )
    return registerAccountRoutes(connectionCtx.connection, CODEX_AUTH_RPC_NAMESPACE, ['status', 'usage', 'login', 'fast-mode'], guard)
  })
  if (config.llmEnabled) {
    ctx.logger.info(
      'llm-codex-auth: route %s serving ChatGPT login from %s (transport %s, ws-connect %sms, request timeout %sms)',
      CODEX_ROUTE, authJsonPath, config.transport, config.websocketConnectTimeoutMs, config.timeoutMs,
    )
  } else {
    ctx.logger.info('llm-codex-auth: shared Login State active at %s; LLM route disabled', authJsonPath)
  }
}
