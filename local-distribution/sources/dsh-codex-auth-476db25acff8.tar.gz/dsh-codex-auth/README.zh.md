# dsh-codex-auth

> **DSH 兼容性：** 此候选版本适配完整一致的 DSH **0.2.2-rc.1 / rc.2 / rc.3 / rc.4** 依赖图及 pi-ai **1.3.0**。实验性 peer 与运行时检查仍拒绝旧版、混合及未来版本，不添加兼容性豁免。旧 Harness 请保留相应旧插件。见[升级指南](docs/dsh-0.2.2-upgrade.md)。

[![npm rc version](https://img.shields.io/npm/v/dsh-codex-auth/rc.svg?label=npm%20rc)](https://www.npmjs.com/package/dsh-codex-auth)
[![awesome · DSH plugin](https://awesome-dsh-plugin.com/badge.svg)](https://awesome-dsh-plugin.com)

[English](README.md) | 中文

候选版本：**v0.3.4-rc.5**。

这是一个自包含的 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)
**Codex 能力包**。它复用官方 **Codex CLI** 维护的 ChatGPT 登录态
（`~/.codex/auth.json`，或 `$CODEX_HOME/auth.json`），同时提供：

- `openai-codex` LLM 路由；
- 接入 DSH 内置 `web_search` 工具的全局 Codex 搜索提供方；
- 通过 `generate_image` 实现持久图片生成与编辑，并提供供模型使用的 `list_images` 目录；
- 稳健的 Codex 周用量状态；
- 一个原生 **GPT Auth** 设置分区，内含「登录」「LLM 上下文」「网页搜索」「图片创作」
  四张卡片；搜索与图片的详细设置可收起为紧凑卡片。

> **⚠️ 非官方通道——仅限个人开发。** 私有、受账户权限控制的
> `chatgpt.com/backend-api` 未获官方支持、可随时撤销，也可能在没有通知的情况下被限流
> 或变更。请勿依赖它承载生产任务。

## Codex SSE 请求

Codex LLM 的 SSE 请求使用未压缩 JSON。适配器在 HTTP 发送前将 pi-ai 的 zstd 请求字节还原为相同 JSON，因为 Codex 后端可能以 `400 {"detail":"Bad Request"}` 拒绝压缩请求。模型、推理级别、加密回放数据、认证、取消和响应处理保持不变；不会重试被拒绝的请求，也不会修改 WebSocket 帧。

## 0.3.4-rc.5：GPT-6.2 和 DSH 0.2.2-rc.4

GPT-6.2 Astra 和 GPT-6.2 Sol 可通过 ChatGPT OAuth 使用，标准上下文分别为 272,000 和 500,000 token。长上下文模式为两者使用 872,000 token。

## 0.3.4-rc.3：DSH 0.2.2-rc.1

更新完整依赖图及必需的图片数量限制，适配工具批处理、modelSelection、客户端资源加载与 replayState v2。保留 V4 会话及 Native codec，不添加版本豁免。见[升级指南与验证边界](docs/dsh-0.2.2-upgrade.md)。

## 0.3.4-rc.2：DSH 0.2.1-rc.1 / rc.2

无需版本豁免即可支持两个已验证的 rc 依赖图，并修正通过 Host 解析器读取运行时包版本的方式。两个依赖图各通过 456 项离线测试，隔离 profile 的官方安装、Host 加载及卸载已验证；真实 OAuth、模型、搜索和生图服务属于独立验证范围。

## 0.3.4-rc.1：DSH 0.2.1-rc.1

更新完整依赖图和经过所有者认证的 browser Peer 接口，移除已退役的 invariant companion，并保留不读取或刷新登录态的静态 Codex 模型目录。对于旧 Native digest 尚未表达的工具搜索或会话中指令更新，创建与回放均保守使用 Portable 文本；V4 会话和 codec v1 不变。源码验证同时应用 Desktop 的准确 pi-ai 1.1.0 运行时补丁。见[升级细节与验证边界](docs/dsh-source-verification.md#upgrade-from-dsh-020-rc2)。

## 0.3.3-rc.4：每个 profile 的模型排除列表

新增默认空列表的 `excludedModelIds`，可通过 GPT Auth 的 LLM 上下文设置实时编辑并持久化。排除在目录补齐和长上下文策略之后按精确 ID 执行，保留其余模型的描述符、参数与顺序；没有默认屏蔽模型，不改写认证、模型选择或既有会话。

## 0.3.3-rc.3：DSH 0.2.0-rc.2

使用完整一致的 rc.2 依赖图与 pi-ai 0.87.1，保留 V4 会话和 checkpoint codec v1，拒绝旧图或混装。既有 checkpoint 的最终请求控制不一致时，仍通过 Portable 文本继续。GPT-6 Sol/Luna 保留已安装 provider 的 Off 元数据；缺失模型的 fallback 继续使用更严格的策略。见[升级验证](docs/dsh-source-verification.md#upgrade-from-dsh-020-rc1)。

## 0.3.3-rc.2：适配 DSH 0.2.0-rc.1

此版本更新 DSH 依赖图，使用 Config Forms 与 volatile 配置，向 Connection RPC 传入新版 operator，并接受 V4 `tool` 角色消息。Native Checkpoint 的兼容门槛固定在此 DSH 版本；公开 LLM middleware 会向非 Codex 提供商投影 Portable 文本。完整包检查与固定源码检查已通过；真实 Codex 登录和提供商回放尚未验证。

下文复制自定义 preset 目录的命令属于旧版 DSH。`0.2.0-rc.1` 的 `@deepseek-ai/dsh-web-app/presets/standard.patch.yml` 包含 `preset-standard` 完整 `config.plugins` 列表。适配 0.2 时，应将整个条目克隆为新的 preset ID，并以本包示例中的 `compaction` group 替换原 group；不要使用已退役的 `@deepseek-ai/dsh-agent-presets` 路径。

## 0.3.3-rc.1：DSH 0.1.5-rc.1 适配

开发基线升级为统一的 DSH `0.1.5-rc.1` 与 pi-ai `0.85.1`。补齐 pi-ai 新增的模型错误映射，使普通和 prepared 模型请求正常进入提供方。压缩与 Native 回放只接受 RC.1，拒绝混装或未验证的依赖图，保留持久 checkpoint 编码及 Portable 回退。

## v0.3.3-alpha.7 重点更新

开发基线升级到 DSH `0.1.5-alpha.1` 与 pi-ai `0.85.1`。Native／Dual Checkpoint 门禁只接受这套经过验证的转换依赖图；JSON 会话恢复显式使用 V3 detached 事件所有权。账号状态、用量与登录使用经过认证的 `/api/codex-auth/*`，保留原有静态 loopback 限制。

新增 GPT Image 2.5 Sunburst／Flare、高画质选项与自定义尺寸校验。新图片配置默认使用 Sunburst，保留已明确保存的模型选择；后端返回尺寸不符时保留有效图片并给出警告。`/codex-auth` 命令提供本地终端账号状态与登录入口。

## v0.3.3-alpha.5 重点更新

- 将开发依赖图与 peer 基线迁移到 DSH `0.1.2-alpha.5`，采用当前 Session snapshot、Settings 注册、Connection 包与 `ToolCallId`；本仓库 lockfile 不含旧 DSH 包族。
- 在 alpha.5 上保持账号 RPC fail-closed：只有明确绑定 `127.0.0.1` 的 Web Host 才能触达认证服务。
- 在 alpha.5 上保留 Dual Checkpoint 创建、回放、重启/fork 持久性与一次性 Turn Continuation。
- 确认 SSE、WebSocket 与自动回退的最终 pi-ai payload 完全一致；在 Native compatibility digest 覆盖 deferred-tool `additional_tools` 历史之前，相关 payload 保守使用 Portable checkpoint。

## 功能

### 共享 Codex 登录态

- LLM、搜索与图片操作共用一个仅运行于 Host 的认证协调器。
- 通过绑定文件版本的认证快照、短时内存缓存解析凭证，并在到期前主动刷新。
- 进程内合并并发刷新；OAuth 网络请求前后各使用一段短跨进程锁，且只有账户与
  refresh token 谱系仍和决策快照一致时才写入响应。
- 可启动官方 `codex login` 浏览器登录或设备码登录流程。
- 在交互式 DSH profile 中注册 `/codex-auth [status|login]`，使终端界面无需 Web 设置卡片即可检查无凭据登录状态或启动官方浏览器流程。账户操作面向本地终端登录入口：本地 DSH Host（无 WebServer，或显式绑定 `127.0.0.1`）可以执行；任何 WebServer 在其它网卡上暴露共享 `commands` 缝的组合都会在不触碰认证服务的前提下拒绝。账户 RPC 仍保留仅 loopback 的 ADR-0008 守卫。
- 设置页显示连接状态，以及尽力获取的周剩余额度和重置时间。固定的
  `/backend-api/wham/usage` 探测有 10 秒 Host 截止时间，并按窗口时长识别七天窗口。
- 插件自有的 `/codex-auth` Connection RPC 不会向浏览器发送任何 token 值。只有 Web
  bind 明确为 `127.0.0.1` 时才注册真实 dispatcher；bind 缺失、面向所有接口或未知时都只返回
  相同且不含状态值的 `loopback-required` 拒绝。

### Codex 模型与长上下文

本仓库锁定的 pi-ai `1.3.0` 目录已包含 GPT-6 Astra。插件会在缺项时以对应的
GPT-5.6 描述符为模板，补入 GPT-6 Sol（`gpt-6-sol`）、Luna（`gpt-6-luna`）和
GPT-6.1 Sol（`gpt-6.1-sol`）；已由上游提供的描述符保持不变。
回退描述符默认使用 272,000 Token 上下文。默认关闭的**长上下文**开关按模型设置预算：
**支持的 GPT-5.6/6/6.1 模型均为 872,000 Token**。
GPT-6 的预算以 Codex OAuth 元数据为依据，不套用公开 API 的上下文上限。
DSH 据此计算 Token 压力和压缩时机；这不会协商后端容量或赋予账户使用权限，
也无法恢复已经压缩的历史。长请求可能更快消耗账户配额。

回退的 GPT-6/6.1 描述符提供 `low`、`medium`、`high`、`xhigh` 和 `max`；
DSH 的 `minimal` 映射到 `low`。不提供 `Off`，因为省略推理参数不代表关闭推理；
不支持的档位会在解析凭据前被拒绝。GPT-6.1 Sol 未选择档位时使用 Codex 的 `low` 默认值。
`Ultra` 属于 Codex 的编排模式，不是本插件可以直接发送的推理档位。
此路由上的 GPT-6/6.1 模型均拒绝显式 `temperature`（包括 `0`），并在解析凭据或发送请求前
返回 `UNSUPPORTED_OPTION`。

详见[模型策略依据与验证边界](docs/codex-model-policy.md)，其中区分 OAuth 与公开 API，
说明价格估算来源和离线测试覆盖范围。

每个 profile 可通过可选的 `excludedModelIds`（默认 `[]`）隐藏精确模型 ID。
在 **GPT Auth → LLM 上下文 → 排除的模型 ID** 中以逗号分隔填写；按回车或离开输入框
时，经现有 `llm-codex-auth` Config Form 保存到当前 profile patch，并实时更新目录。
编辑器会去除两端空白、空项和重复项；原生 profile 配置使用字符串数组，例如：

```yaml
- id: llm-codex-auth
  config:
    excludedModelIds:
      - gpt-5.3-codex-spark
```

默认不排除任何模型。按大小写敏感的精确 ID 匹配，不支持通配符；未知 ID 无影响，
重复 ID 无副作用。排除在缺失模型补齐和长上下文策略之后执行，保留其余模型的描述符、
参数及顺序。清空列表即可恢复目录。它仅影响此 profile 的 `openai-codex` LLM 目录，
不影响搜索或图片设置、认证、账户权益或请求权限。

排除当前模型时，模型选择和既有会话保持不变；之后解析该模型沿用 DSH 的
`UNKNOWN_MODEL` 错误。请重新选择剩余模型，或取消该 ID 的排除后继续。
允许排除全部模型，此时 Codex 目录为空。已经准备好的调用在实际发送时仍会解析目录
可见性；正在执行的请求不会被取消。排除列表不是访问控制机制。

### 实验性 Dual Checkpoint 压缩 Adapter

包额外导出 `dsh-codex-auth/compaction`，仅供用户或部署者在**自定义 Agent preset**
中显式选择。`CodexCompactionEngine` 继承 DSH 的 `BasicCompactionEngine`，并包装手动、
step pressure 与 provider 已确认的 context-overflow 入口。每条路径都会先完成 Basic 原有、
provider-neutral 的 Portable 摘要；Host 随后只在内存中捕获该调用最终且不含 marker 的
Codex payload 与已经解析好的登录态，再发送一次末尾带临时 `compaction_trigger` 的独立
Responses v2 请求。若得到有效 opaque 结果，就把它追加在 Portable 摘要旁，由 Basic 的
同一个继承事务原子提交 **Dual Checkpoint**。选区、pruning、tool pair 平衡、重试上限、
持久 marker、surface replacement 与取消语义仍全部由 Basic 拥有。

Portable 成功永远先发生。路由或模型不一致、前缀为空或含图片、payload 不受支持、超时、
限流、HTTP/协议错误、状态过大或保守 shrink 预检失败时，都会只提交已经有效的 Portable
Checkpoint；Portable 失败则不提交 checkpoint。Native 请求不会重试。进程局部、按
account/model/endpoint/codec 隔离的 circuit breaker 会在五分钟内三次 transient 失败后
打开十分钟，在 protocol 或最终 payload shape 不受支持时打开一小时，并按设有上限的
HTTP 429 `Retry-After` 打开；half-open 只允许一个探测。HTTP 401/403、oversize-state 与
strict-shrink fallback 都不计数。它不会禁用普通推理或 Portable 压缩。插件卸载会中止活跃
Native 工作，并释放请求局部的 credential、payload、marker、canonical item 与 continuation。

Debug 诊断只包含 compaction ID、trigger、codec generation、model、eligibility/status/fallback
class、breaker state、耗时、item/byte 数、回放估算与 usage 是否可用；认证被拒绝时会提示执行
`codex login`。诊断绝不会包含 prompt、tool、header、token、turn state、canonical item、
encrypted content 或 provider 报告的 Token 数值。Native usage 数值可以作为诊断 metadata
保存在敏感 checkpoint 内，但 DSH 的聚合 Token 记账仍只使用 Portable 摘要调用。

一次**内联自动** Native 压缩成功后，provider 响应中非空的 `x-codex-turn-state` 会成为
进程局部的 **Codex Turn Continuation**。只读 `llm/stream` waterfall 会在 Runtime 克隆前
观察 Agent-loop 原始请求；continuation 只会发送给 session、route、model、Codex account
与 Adapter generation 都相同的下一次请求。它在 60 秒后过期，并在首个不匹配的 eligible
请求、取消/错误、route replacement 或插件卸载时清除。Portable 摘要、session-title/辅助
调用、直接 maintenance、`compactRegion()` 与手动 `/compact` 都不会消费或 arm 它；它也
绝不会进入 Session event、checkpoint、UI state、日志、错误或 telemetry。

Native 生成仍只支持从当前 surface 头部开始、且 Portable 调用使用同一个精确
`openai-codex` 模型的前缀；显式 region 与选区内含图片的压缩仍只产生 Portable
Checkpoint，选定前缀之后的图片和其他消息继续留在 DSH tail。canonical 纯文本 user group
按从新到旧顺序在版本化的 64,000 Token JSON 预算内保留，边界处最多保留一个 Unicode-safe
文本前缀。回放估算对 opaque 内容单独采用固定 Codex 规则：base64 解码长度减去 650-byte
envelope allowance；该值不冒充 DSH 的 provider-neutral pressure price。完整 custom block
上限为 2 MiB，最终仍由 Basic 执行权威 strict-shrink 校验。额外 v2 请求会增加延迟并消耗
Codex 配额；其 opaque 状态不含 credential，但仍是敏感会话数据，而且 alpha.5 会在 summary
event 与 replacement message 中各保存一份。

#### 旧版自定义 preset 配置（DSH 0.1.x）

正常安装 Codex 能力包不会启用这个 Adapter。`cordis.patch.yml` 与 DSH 内置 preset
仍然使用 stock Basic 压缩。请通过一个完整、由用户维护的自定义 preset 显式启用：

1. 把本包安装到实际运行 DSH 的 profile（以下示例使用 `web`）。
2. 将 DSH 的完整 Standard preset 复制为新的用户 preset。请选用新的 `PRESET_ID`；以下命令
   会拒绝覆盖已有目录：

   ```sh
   DSH_HOME="${DSH_HOME:-$HOME/.dsh}"
   DSH_ROOT="$(dirname "$(dirname "$(realpath "$(command -v dsh)")")")"
   PRESET_ID=codex-dual
   PRESET_DIR="$DSH_HOME/.agent-presets/$PRESET_ID"

   test ! -e "$PRESET_DIR"
   mkdir -p "$DSH_HOME/.agent-presets"
   cp -R "$DSH_ROOT/node_modules/@deepseek-ai/dsh-agent-presets/presets/standard" "$PRESET_DIR"
   ```

3. 在 `$PRESET_DIR/preset.yml` 中为副本设置独立的 `name` 与 `description`。
4. 在 `$PRESET_DIR/agent.cordis.yml` 中，用下列文件里的完整 `- id: compaction` group
   **替换而不是追加**原有 group：

   ```text
   $DSH_HOME/profiles/web/node_modules/dsh-codex-auth/
   └── examples/agent-presets/codex-portable/agent.cordis.yml
   ```

   只复制示例中的 `compaction` group。该示例刻意不含 persona 或工具，不能替代刚复制的
   Standard preset。最终 group 必须只有一个带 `auto: true` 的
   `dsh-codex-auth/compaction` 行，并保留 `@deepseek-ai/dsh-command-compact` 与
   `@deepseek-ai/dsh-compaction-tool-result-pruner`，且不能包含
   `@deepseek-ai/dsh-compaction-basic`；`ctx.compaction` 只能有一个所有者。
5. 重启 DSH，新建会话并选择该自定义 preset，再选择 `openai-codex` 模型。需要 Native
   回放时，请保持 provider、精确模型、账户以及显式 reasoning 设置不变。

配置 `auto: true` 后，自定义 engine 会自动处理上下文压力压缩和 provider 确认的 context
overflow；`/compact` 则手动调用同一个 engine。所有入口仍然 Portable-first：符合条件的
Codex 请求会增加 Native 同级表示，任何不兼容或 Native 失败都会保留有效 Portable
Checkpoint。即使下一次兼容 provider 请求实际回放 Native，stock conversation 视图仍会
刻意显示 Portable 文本。

该实验性导出支持完整一致的 DSH / Basic compaction `0.2.2-rc.1` 图，要求 pi-ai `1.3.0`；
在其他版本组合上挂载会给出可操作的兼容性错误并失败。长上下文模式可以改变 pressure
压缩的触发时机，但不会改变 Native activation、codec、retention、v2 payload、回放兼容性
或一次性 turn-continuation 契约。回滚时只需重新选择 DSH 内置 preset；已有会话仍可通过
同级 Portable 文本继续，不需要迁移 profile 或会话。当 DSH 提供受支持的 provider-native
checkpoint Seam 时，应迁移到该 Seam，并删除本包的 carrier、请求 side channel、直接
transport、兼容性固定与自定义 Basic replacement；Portable Checkpoint 继续作为恢复路径。

仓库包含会消耗真实 Codex 配额的 live harness，但普通测试、`pnpm run check` 与 CI 都不会
运行它。它会拒绝 `CI`，并要求已有 Codex Login State 以及两个显式确认变量：

```sh
DSH_CODEX_NATIVE_LIVE=1 \
DSH_CODEX_NATIVE_LIVE_CONFIRM=I_UNDERSTAND_CODEX_LIVE_QUOTA \
pnpm run test:live:native-compaction
```

它验证真实 v2 创建、同进程一次性 turn continuation 与 Native 回放、重启/恢复回放、重复压缩
和诊断脱敏。没有另行授权
消耗 live Codex 配额时不要运行；实现过程和普通验证不会触达这一边界。

### Codex Native Checkpoint 回放

普通 `openai-codex` 推理会恢复兼容且已持久化的 **Dual Checkpoint**。在 pi-ai
转换 DSH 消息之前，Host 会把每条完整且有效的 checkpoint 消息替换成请求局部 marker；
provider payload hook 再在原位置把整条 marker item 替换为 canonical Codex Native
Checkpoint items，或替换为一条只含 Portable Checkpoint 的普通 user item。Native 与
Portable 两种表示绝不会同时发给 provider。持久化 block 可安全经过 JSON 存储、
`Session.fromRestore()` 与 `SessionStore.fork()`；重启恢复及 fork 后都能继续回放和再次压缩，
不需要改写 Session。追加新 trigger 之前，选定前缀中的每个兼容 checkpoint 都会在原 item
位置展开；不兼容 checkpoint 只贡献自己的 Portable message，因此仍可生成新的有效 Native
checkpoint 来替换该前缀。所有后续 tail message 与重复 pressure 的收敛或有界失败继续由
Basic 负责。

只有当 checkpoint 的 schema/codec/retention generation、provider、精确 model、哈希后的
Codex account identity、instructions、tools、parallel/tool-choice controls、reasoning、text
配置与 service tier 都匹配**最终生效**的 Responses 请求时，才会执行 Native 回放。Pi-ai
`1.3.0` 可能把 deferred tools 编码为 `additional_tools`、`tool_search_call` 或 `tool_search_output` input item；这些项目和会话中 system/developer 消息的语义历史
不在当前 codec 的兼容 digest 内，因此这类 payload 在回放和新建 Native 时都会保守改用
Portable 文本。组合的 payload callback 可以改变已有建模控制项；callback 完成后会重新判定
并选择 Native 或 Portable。
Request ID、prompt-cache key、临时 header、turn state 与 Long Context Mode 不参与兼容性。
未知、损坏、超过 2 MiB、含 secret、混合格式或不兼容的状态会退化为 Portable 文本。生成的
marker 只存在于 Host；marker 缺失、重复、嵌入、泄漏或未消费时会在网络请求之前失败。
回放 converter 要求 DSH LLM / pi-ai Adapter 同为 `0.2.2-rc.1`，且 pi-ai 为 `1.3.0`；混合或其他
runtime 组合只使用 Portable 文本。Adapter generation 替换或 HMR 会使进程内 replay 与
turn-continuation 状态失效，但不会修改持久化 Dual Checkpoint。

版本化 Host codec 通过 `dsh-codex-auth/native-checkpoint` 导出。它以 lossless JSON 保留
canonical 的纯文本 retained-user Responses items，并要求最后恰有一个 opaque compaction
item；credential、带命名空间的原始账号/路由标识、header、原始 turn state 与请求局部元数据
都会被拒绝，持久化的账号信息只有带 domain separation 的 hash。block 还带有空的通用展示
sentinel，因此 stock conversation 与 trajectory 只显示/复制同级 Portable 文本，不会把
opaque state JSON 化展示。该无凭据 opaque block 在 alpha.5 中仍是敏感的普通 Session 数据，
可能存在于 Session RPC 与导出中，使用这些表面时仍须按敏感数据处理。
随 DSH 发布的 PiAiAdapter 与 direct DeepSeek Adapter 在 provider wire 上只发送 Portable
文本。转换使用脱离 Session 的请求副本，因此在下一次压缩前切回兼容 Codex route，仍可回放
保留的 Native 状态。切回 stock Basic preset 同样不需要迁移 Session；不兼容状态会继续走
Portable 文本。任意第三方 Adapter 若拒绝 declaration-merged 未知 block，仍属于该实验方案
的限制。Native 创建仍要求显式选择自定义 preset，也不会修改 `cordis.patch.yml`。

### 网页搜索

`codex-search` Host 行通过 `@deepseek-ai/dsh-web` 注册 ID 为 `codex` 的提供方。
bundle patch 会将它选为部署全局搜索提供方；用户后续 profile patch 仍可覆盖该选择。
每次搜索向官方独立搜索端点发起请求：

```text
https://chatgpt.com/backend-api/codex/alpha/search
```

若调用方是 `openai-codex` Agent，搜索会使用该 Agent 的当前模型；其他 provider
或无法解析调用方时使用设置中的备用模型。结果只包含后端生成的输出，以及从已识别字段
中提取、去重并验证过的 HTTP(S) 来源；不会编造标题、日期、摘要，也不会继续抓取网页。

网络错误与 HTTP 5xx 使用可取消的指数退避，最多尝试五次；HTTP 429 立即返回。

可实时生效的搜索设置：

| 设置 | 默认值 | 可选值 |
|---|---:|---|
| 启用 | `true` | 开 / 关 |
| 模式 | `live` | `live`、`cached`、`indexed` |
| 上下文大小 | `medium` | `low`、`medium`、`high` |
| 备用模型 | `gpt-5.6-terra` | Codex 模型 ID |
| 最大输出 Token | `2048` | 正整数 |

### 图片创作

`generate_image` 对模型呈现为单一操作，并按有无参考图分发到官方 Codex 图片端点：

```text
POST https://chatgpt.com/backend-api/codex/images/generations
POST https://chatgpt.com/backend-api/codex/images/edits
```

参数包括必填 prompt、最多五个显式参考图、1–10 张输出、受支持的尺寸/质量/背景选项，
以及可选模型覆盖。参考图必须明确区分来源：

```json
{ "kind": "session", "handle": "image:<attachmentId>" }
{ "kind": "workspace", "path": "assets/reference.png" }
```

Session handle 只有在当前会话历史中的持久 ImageBlock 已授权对应附件时才可解析。
工作区读取必须留在当前 workspace 内，通过 `ctx.fs` 执行，并在远程请求前提升到附件存储。
不接受 HTTP(S) 参考图 URL。

后端返回的 base64 会经过编码大小限制、解码、文件签名检查、部署媒体策略验证，并通过
`ctx.attachments.saveImage(...)` 持久保存。多图响应会保留有效图片，并为缺失或无效条目
返回结构化 warning；只有一张有效图片都没有或响应 envelope 不可用时，整次调用才失败。
图片请求一旦发出便不会自动重试。

`list_images` 按最新优先分页列出当前会话的持久图片（默认 5 张、最多 10 张），支持不透明
cursor 和来源筛选，同时返回稳定 Image Handle 与真实 ImageBlock，使支持图片的模型在压缩
上下文后仍能查看旧图片。

图片工具只注册到使用 `openai-codex` 且明确声明支持图片输入的 Agent scope；执行时会再次
校验相同的路由、模型、登录态和套餐条件。若本地明确识别为 Free 套餐，会标记为不可用；
套餐未知时仍允许尝试，以后端结果为准。

可实时生效的图片设置：

| 设置 | 默认值 | 可选值 |
|---|---:|---|
| 启用 | `true` | 开 / 关 |
| 图片模型 | `gpt-image-2.5-sunburst` | Sunburst、Flare、`gpt-image-2` 或自定义模型 ID |
| 图片数量 | `1` | 1–10 |
| 尺寸 | `auto` | `auto`、`1024x1024`、`1536x1024`、`1024x1536`，或通过校验的 GPT Image 2.5 `宽x高` |
| 质量 | `auto` | `auto`、`low`、`medium`、`high`；GPT Image 2.5 另支持 `xhigh`、`max` |
| 背景 | `auto` | `auto`、`opaque`、`transparent` |

GPT Image 2.5 使用明确的模型 ID：`gpt-image-2.5-sunburst` 与
`gpt-image-2.5-flare`。新配置默认使用 Sunburst，保留用户已显式保存的模型设置。
模型输入框提供候选项，也允许自定义 ID；新画质和自定义尺寸仅对这两个已知 2.5 ID
开放，其他 ID 保留原有参数集合。

自定义尺寸要求边长为 16 的倍数、宽高比在 1:3～3:1、单边不超过 3840，
总像素为 655,360～8,294,400；超过 2560×1440 为实验性分辨率。
尺寸输入框在离开或按回车时保存有效值，不保存无效输入。DSH 附件部署限制仍然有效。
参数依据见[官方图片参数文档](https://developers.openai.com/api/docs/guides/image-generation#size-and-quality-options)。

Codex 端点行为仍取决于账号和后端。2026-09-09 实测两个 ID 的生成和编辑均成功，
包括 `xhigh` / `max` 编辑请求，但显式请求 1024×1024 和 1536×864 时均返回了
1254×1254 图片。HTTP 成功不能证明后端实际执行了指定画质或尺寸。
插件保留有效图片；实际尺寸不符时返回含请求尺寸和真实尺寸的 `IMAGE_SIZE_MISMATCH`
warning。详见[验证记录](docs/gpt-image-2.5-compatibility.md)。

成功的 `generate_image` 结果只展示插件自有的图片画廊；`list_images` 是供模型使用的目录状态，
不提供面向用户的结果视图。插件通过公开的会话授权附件 API 读取图片，使用有界 Blob URL 缓存，
并在连接重置、淘汰和插件卸载时回收自身 URL。生成图会作为对话附件持久保存。
DeepSeek Harness `0.1.2-alpha.5` 尚未提供二进制工作区写入 API，因此界面不提供工作区导出操作；
插件也不会通过 Node 文件系统绕过 DSH 的文件策略。

### ACP 图片互操作

当当前 `openai-codex` 模型明确声明支持图片输入时，ACP 客户端可以发送 PNG、JPEG、
WebP 或 GIF 内联图片。DSH 会在用户消息入队前完成校验和持久化，因此这些图片会作为普通的
`user` 图片进入本插件的图片目录，之后可通过 Image Handle 选作 `generate_image` 参考图。

DSH alpha.5 会把持久化 `tool/call` 与 `tool/result` 事件分别投影为 ACP
`tool_call` 与 `tool_call_update` 消息，因此完成的 `generate_image` 结果可以直接通过该工具更新携带图片内容，
不再要求后续 assistant 消息另含 ImageBlock。

## 环境要求

- DeepSeek Harness `0.2.2-rc.1`（统一依赖图）；不要与旧 rc 包族混装。
- Node.js `^22.19.0` 或 `>=24.0.0`。
- `PATH` 中可用 `pnpm`（本项目测试版本为 `11.28.5`）。
- `codex` CLI 已加入 `PATH`。
- 可提前执行 `codex login`，也可在 GPT Auth 卡片中启动登录。

## 安装

见[升级证据与测试方法](docs/dsh-0.2.2-upgrade.md)。先停止 `dsh web`，确认目标 Host 使用统一的 DSH `0.2.2-rc.1` 依赖图，再将此准确预发布版本安装到目标 profile：

```sh
dsh --version
dsh plugin --profile web add /absolute/path/to/dsh-codex-auth-0.3.4-rc.5.tgz
dsh plugin --profile web list
```

核对条目后重启 `dsh web` 并刷新浏览器。此版本通过 npm 的 `rc` 标签发布；不指定版本或标签会使用 `latest`，它不包含本次 DSH 0.2 适配。旧 DSH Host 应保留兼容的旧插件版本。

## Host 配置

能力包 patch 按依赖顺序启用三条独立 Host 行：

| 行 | Export | 作用 |
|---|---|---|
| `llm-codex-auth` | `dsh-codex-auth` | 共享认证协调器与 LLM 路由 |
| `codex-search` | `dsh-codex-auth/search` | 全局搜索提供方 |
| `codex-image` | `dsh-codex-auth/image` | Agent scope 图片工具 |

认证 / LLM 行字段全部可选。设置 `llmEnabled: false` 后仍保留供搜索/图片能力使用的
共享登录状态协调器，但不再注册 LLM 路由：

| 字段 | 默认值 | 含义 |
|---|---|---|
| `llmEnabled` | `true` | 注册 `openai-codex` LLM 路由 |
| `authJsonPath` | `''` → `$CODEX_HOME`/`~/.codex/auth.json` | Codex 登录文件 |
| `credentialRef` | `CODEX_CHATGPT_TOKEN` | 状态卡展示的非敏感引用 |
| `refreshLeadMs` | `300000` | token 到期前的刷新提前量（毫秒） |
| `codexCommand` | `codex` | 登录和版本探测使用的 CLI 命令 |
| `displayName` | `OpenAI Codex (chatgpt)` | 模型选择器中的 provider 名称 |
| `fastModeEnabled` | `false` | 每个 profile 的实时 Fast（优先处理）请求；保留模型及推理级别，订阅内额度按标准的 2.5 倍消耗，已购积分按 2 倍计费；实际可用性取决于后端 |
| `longContextEnabled` | `false` | GPT-6/6.1 / GPT-5.6 按模型设置的实时长上下文策略，通过 `llm-codex-auth` Config Form 编辑 |
| `excludedModelIds` | `[]` | 每个 profile 在目录补齐及上下文策略之后按精确 ID 隐藏的模型；可通过 GPT Auth 设置编辑 |
| `transport` | `sse` | 流式传输方式：`sse`、`websocket` 或 `auto`（优先 WebSocket、失败回退 SSE）。默认 SSE：WebSocket 升级在常见 HTTP 代理下不稳定，且 `auto` 模式下每个新对话都要先付出连接超时才会回退 |
| `websocketConnectTimeoutMs` | `5000` | WebSocket 连接超时（毫秒，仅当 `transport` 不是 `sse` 时生效；`0` 表示禁用） |
| `timeoutMs` | `120000` | 请求超时（毫秒，SSE 响应头阶段；同时作为 WebSocket 消息空闲间隔；`0` 表示禁用） |

不要再在 `llm-pi-ai.providers` 下添加 `openai-codex`，也不要同时安装 `dsh-codex`；
重复路由所有权会得到明确诊断并被拒绝。

## 安全与限制

- token 值不会进入浏览器、设置、日志、会话事件、工具 metadata、搜索参数或图片结果；
  只有 Host 侧请求会收到认证 header。
- 状态可包含本地解码的账户 ID 和套餐 claim；它们是身份/状态信息，不是凭证。
- 刷新写回会保留未知字段，并以仅属主可读写（`0600`）权限原子替换登录文件。
- 只有公开 WebServer bind 精确为 `127.0.0.1` 时才启用账户 RPC dispatcher。bind 缺失、
  `0.0.0.0` 或未知时会使用固定、不含状态值的 `loopback-required` handler，且不会触达认证
  service。alpha.5 没有公开的逐方法或 carrier authority 事实，因此自定义 owner-contained
  transport 也会被保守拒绝。客户端 `isLoopback` 只用于隐藏设置界面，不是授权边界；特别是
  通过 localhost URL 打开面向所有接口的 Host 时，可能仍看到设置行，但所有账户操作都会被
  Host RPC 拒绝。
- 非 loopback 客户端不注册 GPT Auth 设置与账号 RPC binding，但仍保留 `generate_image` 与 `list_images` 结果视图。
- 图片附件 ID 不是 bearer capability；会话历史中必须存在对应的持久 ImageBlock。
- 若 Codex 只把凭证放在系统钥匙串，`auth.json` 可能没有可用 token。可在
  `~/.codex/config.toml` 设置 `cli_auth_credentials_store = "file"`，再执行
  `codex login`。
- 在 DSH 提供受策略约束的二进制写入 API 之前，二进制 Workspace Export 暂不可用；
  对话附件持久化已经完整支持。

## 开发

```sh
pnpm install
pnpm run check
```

`pnpm run build` 生成：

- `lib/index.js`：认证 / LLM Host 插件；
- `lib/search.js`：搜索 Host 插件；
- `lib/image.js`：图片 Host 插件；
- `lib/compaction.js`：供自定义 preset 使用的实验性 Dual Checkpoint 压缩 Adapter；
- `lib/native-checkpoint.js`：版本化 Host codec 与回放兼容性契约；
- `lib/client.cjs`：兼容 Loader、内联 CSS Modules 的浏览器插件；
- `lib/types/**`：类型声明。

另见 [`docs/design.md`](docs/design.md) 与[架构决策记录](docs/adr/)。

## 友情链接

- [L 站](https://linux.do/)

### Fast 模式

在 **Settings → GPT Auth → LLM Context** 启用 **Fast 模式**，可为当前 profile
后续的 Codex LLM 请求申请优先处理，无需重启。配置为 `llm-codex-auth.config.fastModeEnabled`
（默认 `false`）。保留模型及推理级别，搜索和图片工具维持各自设置。
实际处理层级及可用性由模型和账户决定，不保证延迟改善。
参见 [OpenAI 速度指南](https://learn.chatgpt.com/docs/agent-configuration/speed)。
请求通过兼容的 `service_tier: priority` 在 Native 兼容性检查之前写入；
切换后不匹配的 Native 检查点将回退到 Portable 摘要，已有检查点格式保持不变。

底部统计栏显示 Codex 五小时及每周剩余额度，悬停或聚焦可查看重置时间，点击可刷新；
页面可见时每5分钟自动更新。不显示账户未提供的窗口，也不会把未知额度当成零。
它通过现有的仅限回环连接的账户 RPC 获取数据，与上下文占用百分比独立。

底栏还提供仅针对当前会话的 Fast 开关，选择写入模型历史之外的可忽略插件记录，
恢复和分支保留该选择，其他会话及 Codex CLI 配置不受影响。
显式关闭发送 `service_tier: default`，未设置的会话继承 profile 默认值。
实验性插件记录可能在未来格式迁移中丢失，此时恢复为 profile 默认值。

本次 DSH 0.2.2-rc.1 订阅实测中，Astra、GPT-6.1 Sol 和 GPT-5.6 Sol 接受了 priority 请求，
但完成响应报告 `service_tier: default`；直接发送 fast 别名返回 HTTP 400。
因此仅验证了参数送达，尚未证实获得 Fast 处理或速度提升。

点击底栏额度可打开订阅详情窗口，查看套餐、剩余额度、重置时间及上次检查时间。
页面可见时每5分钟自动更新数据，无需刷新按钮；更新时保留当前值，失败时明确标记为上次已知的过期数据。
重新连接会清除旧快照，避免账户混用。

新会话的选项行同样显示 Fast 开关及 Codex 额度，可在首条消息前设置该会话的 Fast，并查看额度详情；开始聊天后保留所选状态。

图片错误区分安全审核阻止、请求拒绝、登录失效、访问拒绝、路由不可用及限额。错误卡片显示本地化说明，不会将上游原始响应写入会话，也不会自动重试。可在 GPT Auth → Image Creation 的模型下拉列表中选择 Sunburst 或 Flare；尺寸支持 WIDTHxHEIGHT，质量支持 auto、low、medium、high、xhigh、max。现有自定义模型 ID 仍可选择；新的自定义 ID 可通过 cordis.yml 配置。

生成图片直接显示在已完成的助手回复下方，即使处理详情已折叠也可见。“编辑图片”在所选图片旁打开模型、预设或自定义尺寸、质量及修改描述。“创建图片”可从新会话首页或当前输入框旁打开，用于从零生成图片。“添加到消息”将图片引用和本次参数追加到可见草稿并保留已有文字；检查并发送消息后才开始处理。这些选择仅应用于本次请求，不修改全局默认设置。每张图片下显示实际输出尺寸；生成失败的详情仍显示在工具处理视图中。
