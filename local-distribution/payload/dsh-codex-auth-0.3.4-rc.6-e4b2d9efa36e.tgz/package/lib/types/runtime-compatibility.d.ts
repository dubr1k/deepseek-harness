/** Each supported DSH graph is verified independently; mixed graphs are never accepted. */
export declare const SUPPORTED_DSH_RUNTIMES: readonly string[];
/** Observed coherent prereleases; future RCs and stable releases need their own verification. */
export declare const SUPPORTED_DSH_PEER_RANGE = "0.2.2-rc.1 || 0.2.2-rc.2 || 0.2.2-rc.3 || 0.2.2-rc.4";
export declare function isSupportedDshGraph(versions: readonly string[]): boolean;
/** Development version of the Pi converter shared with the updated Harness build. */
export declare const CURRENT_PI_AI_VERSION = "1.5.2";
/** Accept the converter versions shipped by the original Desktop and the updated build. */
export declare function isSupportedPiAiVersion(version: string): boolean;
//# sourceMappingURL=runtime-compatibility.d.ts.map