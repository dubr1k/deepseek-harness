import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { ImageQuality } from '../image-options.ts';
import type { CodexAuthKey } from './locales.ts';
/** Local choices embedded in one visible user request, without saving profile settings. */
export interface ImageRequestChoices {
    model: string;
    size: string;
    quality: ImageQuality;
}
/** Build an explicit image request in the main composer, preserving the user's send decision.
 * @param props Optional source image, initial choices, draft preparation and localized copy.
 * @returns Model, size, quality and description controls.
 */
export declare function ImageRequestPanel({ image, initial, prepare, onPrepared, t }: {
    image?: ImageAttachmentRef;
    initial?: ImageRequestChoices;
    prepare: (prompt: string) => boolean;
    onPrepared?: () => void;
    t: (key: CodexAuthKey) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=ImageRequestPanel.d.ts.map