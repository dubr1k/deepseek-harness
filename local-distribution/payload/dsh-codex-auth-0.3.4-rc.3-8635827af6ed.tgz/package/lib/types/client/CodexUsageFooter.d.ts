import type { ReactNode } from 'react';
import type { CodexAuthRpcClient } from '../rpc-contract.ts';
import type { CodexAuthKey } from './locales.ts';
export interface CodexUsageFooterProps {
    sessionId?: string;
    rpc: CodexAuthRpcClient;
    t: (key: CodexAuthKey) => string;
    subscribe: (listener: () => void) => () => void;
}
export declare function CodexUsageFooter({ rpc, t, subscribe, sessionId }: CodexUsageFooterProps): ReactNode;
//# sourceMappingURL=CodexUsageFooter.d.ts.map