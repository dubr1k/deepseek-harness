import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { ImageLoader } from './CodexImageGallery.tsx';
import type { ImageRequestChoices } from './ImageRequestPanel.tsx';
import type { CodexAuthKey } from './locales.ts';
interface ImageTurnState {
    readonly turn: number;
    readonly calls: ReadonlySet<string>;
    readonly images: readonly ImageAttachmentRef[];
}
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface ConversationTurnDataMap {
        /** Generated outputs owned by this turn; reference inputs are excluded. */
        codexImages: readonly ImageAttachmentRef[];
    }
}
/** Fold durable successful image outputs into the existing turn-artifact extension. */
export declare const generatedImageDefinition: ConversationNodeDefinition<ImageTurnState>;
/** Display stored images and prepare an explicit edit draft without sending it.
 * @param props Generated outputs, authorized loader, draft action and localized copy.
 * @returns Gallery with one edit action per image, or null for an empty turn.
 */
export declare function CodexTurnImages({ images, loadImage, editImage, initial, t }: {
    images: readonly ImageAttachmentRef[];
    loadImage: ImageLoader;
    editImage: (image: ImageAttachmentRef, prompt: string) => boolean;
    initial?: ImageRequestChoices;
    t: (key: CodexAuthKey) => string;
}): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=CodexTurnImages.d.ts.map