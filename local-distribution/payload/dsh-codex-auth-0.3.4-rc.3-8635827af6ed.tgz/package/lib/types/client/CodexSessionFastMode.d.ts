import type { ReactNode } from 'react';
import type { CodexAuthRpcClient } from '../rpc-contract.ts';
import type { CodexAuthKey } from './locales.ts';
export declare function CodexSessionFastMode({ rpc, sessionId, t, subscribe }: {
    rpc: CodexAuthRpcClient;
    sessionId: string;
    t: (key: CodexAuthKey) => string;
    subscribe: (listener: () => void) => () => void;
}): ReactNode;
//# sourceMappingURL=CodexSessionFastMode.d.ts.map