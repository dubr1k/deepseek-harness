import type { ImageRequestChoices } from './ImageRequestPanel.tsx';
import type { CodexAuthKey } from './locales.ts';
/** Open per-request image controls from the blank-session or active composer.
 * @param props Local defaults, draft action and localized copy.
 * @returns Creation trigger and its settings dialog.
 */
export declare function ImageCreateAction({ prepare, initial, t }: {
    prepare: (prompt: string) => boolean;
    initial?: ImageRequestChoices;
    t: (key: CodexAuthKey) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=ImageCreateAction.d.ts.map