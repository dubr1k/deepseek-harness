/** Best-effort, fork/resume-preserved plugin preference outside model history. */
import { type Session } from '@deepseek-ai/dsh-session';
import type { CodexFastModeView } from './rpc-contract.ts';
declare module '@deepseek-ai/dsh-session/types' {
    interface PluginRecordMap {
        'plugin:dsh-codex-auth/fast-mode': {
            enabled: boolean;
        };
    }
}
export declare function sessionFastMode(session: Session | undefined): boolean | undefined;
export declare function sessionFastModeView(session: Session, profileDefault: boolean): CodexFastModeView;
export declare function saveSessionFastMode(session: Session, enabled: boolean): void;
//# sourceMappingURL=codex-session-fast-mode.d.ts.map