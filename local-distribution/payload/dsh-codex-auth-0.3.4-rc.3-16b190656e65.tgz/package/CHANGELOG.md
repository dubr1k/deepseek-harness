# Changelog

## Unreleased

- Qualify coherent DSH 0.2.2-rc.2 with pi-ai 1.3.0 while retaining verified rc.1 admission and rejection of mixed/future graphs. Update the development/source baseline and pnpm toolchain, use the shared HarnessError for the custom credential-persistence failure, and retain genuine deferred-tool-history coverage under rc.2 declaration rebasing.

- Correct the enabled GPT-5.6 long-context budget from 1,000,000 to the verified Codex OAuth maximum of 872,000 tokens. Stock Basic compaction can now trigger before the advertised backend maximum; GPT-6/6.1 budgets and user compaction policies are unchanged.

- Send Codex SSE requests as uncompressed JSON to avoid backend `400 {"detail":"Bad Request"}` rejection of zstd bodies. Preserve encrypted reasoning and tool history, request credentials and cancellation; do not retry rejected requests or change WebSocket frames.

- Add per-request model, resolution and quality controls beside edited images and through Create image on the main screen and chat composer; show actual output dimensions.

- Show generated images directly in completed chat turns and add Edit image to prepare a session-specific edit draft without replacing existing text or automatically sending it.

- Pass the complete image reference to session-authorized attachment reads so generated images load in the current Harness client.

- Distinguish image moderation and HTTP failures with localized explanations without automatic retries or raw upstream response disclosure.
- Use a model dropdown for Sunburst and Flare; preserve configured custom model IDs and existing size and quality controls.

## [Unreleased]

- Read and persist conversation Fast preferences through the existing live Session writer, including resident subagent Sessions, without claiming or replacing their Agents through ordinary Session routing.

- Show session-scoped Fast and subscription-limit controls in the New Session options row before the first prompt, reusing the existing composer dock controls and account boundary.

- Open a subscription details dialog from the quota pill instead of clearing values on click. Show plan, remaining allowances, reset times and last-check timestamp, with automatic five-minute refresh and explicit last-known/stale handling after failures.

- Add a per-conversation Fast switch to the composer dock. Persist explicit On/Off in an ignorable plugin record outside model history, retain it through resume/fork, inherit the profile default otherwise, and keep unrelated sessions and Codex CLI settings untouched. Explicit Off requests the `default` tier.

- Show remaining five-hour and weekly Codex allowances in the public composer dock, with reset-time hints, automatic five-minute refresh, missing-window handling, and cancellation/reconnect cleanup. Keep the existing loopback-only account boundary and context occupancy display.

- Add default-off, live per-profile Fast mode in GPT Auth settings. Request `service_tier: priority` without changing the selected model or reasoning effort, and explain the subscription usage multiplier and backend-dependent availability.
- Apply the tier before Native replay checks and compaction payload capture for both provider stream entry points. Preserve existing payload callbacks and independent Search/Image settings.
- Cover direct/prepared live toggling, persistence and profile isolation, UI writes, Native tier propagation and Portable fallback after a tier change.

## [0.3.4-rc.3]

- Target the coherent DSH `0.2.2-rc.1` graph with Cordis `4.1.0`, Schemastery `3.19.0`, and pi-ai `1.3.0`; retain exact experimental runtime guards and reject mixed or future graphs.
- Supply the new pi-ai image-count/offload limits and update tool-batch, pre-step model-selection, client asset-loader, and response replay fixtures to the new public contracts.
- Exclude the retained system head from Native summary shrink accounting, so an oversized Native result falls back to the valid Portable summary instead of failing Basic's transaction.
- Cover released-plugin admission rejection, adapted admission, old V4 restore/fork/replay, model catalog preservation, and retained-system shrink fallback. Document removal of an obsolete duplicate `llm-pi-ai.providers.openai-codex` registration.
- Record live image generation/edit/catalog persistence, search and Native compaction checks; document migration of retired saved-preset rows and model-selection flags, and account-specific model exclusions.

## [0.3.4-rc.2] - 2026-10-17

- Admit the two verified DSH 0.2.1 prereleases with `0.2.1-rc.1 || 0.2.1-rc.2` for the three experimental peers and matching Native/compaction runtime guards; retain coherent-graph and exact pi-ai checks.
- Read runtime package identities through the Host resolver before inspecting package metadata; avoid false Native/compaction refusal after a real pnpm profile installation.
- Cover real installation admission, unknown prerelease/stable refusal, mixed supported graphs, and the Web Config contract used by rc.2.

## [0.3.4-rc.1] - 2026-10-17

- Target the coherent DSH `0.2.1-rc.1` graph with Cordis `4.0.5`, Schemastery `3.18.5`, and pi-ai `1.1.0`; keep exact experimental Native/compaction gates and the npm `rc` channel.
- Remove the retired `dsh-invariants` dependency and `./invariant` companion export. Adapt account routes to the owner-authenticated browser Peer, and update Settings/stock tool-view contracts.
- Preserve the static Codex catalog without credential reads or refreshes, including live per-profile exclusions; actual model requests still require Login State.
- Stop Image eligibility refreshes after row disposal, including an initial Login State read that settles after unload; cover the real plugin-fiber lifecycle without swallowing errors.
- Use Portable checkpoints for tool-search/deferred-tool history and in-history system/developer updates whose semantics are not represented in the existing Native digest. Keep V4 sessions and codec v1 unchanged.
- Add frozen rc.4 admission evidence, genuine synthetic rc.2 session restore/fork/replay coverage, and source checks carrying the exact Desktop pi-ai runtime patch. Live OAuth, private backend requests and an installed Desktop are separate verification steps.

## [0.3.3-rc.4] - 2026-10-14

- Add optional per-profile `excludedModelIds`, defaulting to an empty list, with exact case-sensitive filtering after model completion and long-context policy. Preserve remaining provider descriptors, parameters, order, and source objects; no model is excluded by default.
- Add a bilingual GPT Auth editor that saves through the existing volatile Config Form and profile patch, updates the live catalog without remounting, and blocks editing while a save is pending to preserve write intent.
- Keep model selections, existing sessions and authentication untouched. Missing model resolution uses the host's `UNKNOWN_MODEL` behavior, including prepared dispatch; excluding all models leaves an empty catalog. Visibility filtering is not request access control.
- Cover default/unknown/duplicate IDs, completed descriptors, long-context compatibility, immutability, empty catalogs, delayed UI saves, profile isolation and restart persistence with synthetic profiles and offline transport.

## [0.3.3-rc.3] - 2026-09-30

- Move the coherent DSH baseline to `0.2.0-rc.2` and pi-ai to `0.87.1`, including exact Native/compaction gates, lockfile, source-tag checks, and package verification.
- Verify rc.1 profile admission versus rc.2, stale exact-version exemptions, V4 restore/fork/continuation, and Portable fallback for a changed final-request digest without migrating checkpoint data.
- Preserve pi-ai 0.87.1 GPT-6 Sol/Luna descriptors, including upstream Off support; missing-model fallbacks still reject Off/Ultra before credentials.
- Add GPT-6.1 Sol with Codex low-effort defaults and supported reasoning levels.
- Remove misleading Off reasoning for fallback GPT-6 Sol/Luna descriptors; reject unsupported requests before credential resolution.
- Use the Codex GPT-6/6.1 long-context cap of 872K instead of the generic 1M overlay, preserving provider descriptors and the existing GPT-5.6 policy.
- Cover direct/prepared requests with offline successful SSE decoding, option validation, and immutable catalog tests. Live account access and backend capacity remain unverified.

## [0.3.3-rc.2] - 2026-09-28

- Align the plugin and its dependency graph with DSH `0.2.0-rc.1`; migrate Config Forms, volatile settings, Connection RPC, and V4 tool messages.
- Pin Native Checkpoint compatibility to this DSH release and project Portable checkpoint text for non-Codex providers through the public LLM middleware.
- Verify with the full package gate and artifacts built from the official DSH source tag; live Codex login and provider replay remain unverified.

## [0.3.3-rc.1] - 2026-09-10

- Targets the coherent DSH `0.1.5-rc.1` graph with pi-ai `0.85.1`. Supplies the new pi-ai model-error map so ordinary and prepared model requests reach the provider. Compaction and Native replay accept exactly RC.1, reject mixed/unverified graphs, and preserve the durable checkpoint codec and Portable fallback.

## [0.3.3-alpha.7] - 2026-09-09

- Adds GPT Image 2.5 Sunburst/Flare model suggestions, `xhigh`/`max` quality, validated custom dimensions, and matching Host/client settings support. New image configurations default to Sunburst while explicit existing choices remain intact. Valid outputs whose dimensions differ from the request carry `IMAGE_SIZE_MISMATCH` warnings.

- Moves the development baseline to DSH `0.1.5-alpha.1` and pi-ai `0.85.1`. Native and Dual Checkpoint gates accept only that verified conversion graph; restored JSON sessions explicitly use V3 detached event ownership. Account status, usage, and login use authenticated `/api/codex-auth/*` routes, retaining the static loopback guard.

### Added

- Added a `/codex-auth` slash command (`status` default, `login`) on surfaces that host the DSH `commands` seam. Account operations are the terminal login entry point: they run on a local DSH Host (no WebServer, or an explicitly `127.0.0.1`-bound one) and are denied before touching the auth service whenever the WebServer exposes the shared commands seam on another interface. `login` spawns the official `codex login` CLI, which owns the browser PKCE flow.

## [0.3.3-alpha.6] - 2026-09-07

- Add explicit DSH `0.1.3-alpha.1` source compatibility alongside the npm alpha.5 baseline; keep dependency graphs separate.
- Add reproducible isolated source-package checks and coherent lockfile validation.
- Accept only homogeneous, verified DSH versions for compaction/native replay; retain pi-ai `0.84.4` and reject mixed graphs. Update Session v2 settlement and restore fixtures.

### Added
- Surfaced GPT-6 Astra (`gpt-6-astra`) on the `openai-codex` route when the installed pi-ai catalog omits it, using the official Codex descriptor (image input, no `none` reasoning, 272K default context).
- Extended the default-off 1M context policy to GPT-6 Astra.

### Changed

- Default Codex Search fallback model from retired `gpt-5.4` to `gpt-5.6-terra`.

## [0.3.3-alpha.5] - 2026-09-03

### Changed

- Migrated the development and peer baseline as one graph to DSH `0.1.2-alpha.5`, Cordis `4.0.2`, Schemastery `3.18.2`, and pi-ai `0.84.4`, including the split Connection, Settings, Session, and client UI package owners.
- Ported Session consumers to alpha.5 snapshot accessors and the explicit `inheritedEventCount` restore contract; migrated settings registration to `ctx.settings.installSection()` and tool identifiers to `ToolCallId`.
- Moved the exact experimental compaction and Native replay gates to DSH / Basic `0.1.2-alpha.5` with pi-ai `0.84.4`, validated final payload parity across SSE, WebSocket, and automatic fallback, and deduplicated the lock graph so the plugin and DSH Adapter share one pi-ai runtime. Final Codex payloads containing deferred-tool `additional_tools` history now conservatively use Portable creation and replay.
- Updated the stock presentation fixture for alpha.5's Chat / Trajectory client-module batches while preserving the non-copyability of opaque Native state, and emitted the CommonJS browser bundle with the unambiguous `.cjs` extension.
- Refreshed the release README for exact prerelease installs, corrected the alpha.5 Standard preset source and ACP tool-result image delivery, and removed obsolete rc migration guidance.

### Security

- Replaced the removed Connection authority tier with a fail-closed static Host guard: only an explicit `127.0.0.1` Web bind reaches account RPC, while missing, all-interface, and unknown binds receive one value-free `loopback-required` handler that never calls auth services. Client loopback detection remains UX-only.

## [0.3.2] - 2026-09-02

### Added

- Added an experimental, Portable-first `dsh-codex-auth/compaction` Host Adapter and a packaged custom-preset example that retains the stock compact command and tool-result pruner.
- Documented the Portable, Codex Native, and Dual Checkpoint vocabulary plus the custom-preset/Basic-subclass architecture decision.
- Added the versioned `dsh-codex-auth/native-checkpoint` Host codec for lossless, bounded text-retention history ending in one opaque Responses compaction item.
- Added Portable-first Codex Native Checkpoint creation for Basic pressure and provider-confirmed context-overflow operations, plus a 60-second one-shot Codex Turn Continuation for the next matching Agent-loop request.

### Changed

- Pinned the experimental compatibility set to DSH `0.1.1-rc.2` and pi-ai `0.82.1`; the custom compaction Adapter fails loud, Native replay falls back to Portable text, and shipped presets keep using stock Basic unless a custom preset opts in.
- Restored compatible durable Codex Native Checkpoints during ordinary `openai-codex` inference while preserving one exact-position Portable fallback for every incompatible or malformed candidate.
- Kept Basic authoritative for automatic trigger timing, pruning, balanced selection, retry caps, durable markers, strict shrink, surface mutation, and cancellation while the custom Adapter adds only native generation and one-shot continuity.
- Preserved immutable Dual Checkpoints across JSON restore, public forks, stock-Basic rollback, and round trips through the shipped foreign Adapters; final payload callbacks and Adapter generation changes now reselect Native or Portable without rewriting Session state.
- Made Native v2 failure degradation predictable: unsupported final Portable shapes now open the protocol breaker, half-open remains single-probe, active direct requests abort on Adapter disposal, ordinary inference stays independent, and logs expose usage availability without provider token values or merging Native usage into rc.2 aggregate accounting.
- Completed repeated compaction semantics with ordered expansion of compatible earlier checkpoints, Portable contribution from incompatible checkpoints, later-tail preservation, Basic-owned bounded pressure behavior, and the versioned retained-JSON plus opaque-base64 replay estimator under the 64,000-token retained-prefix policy.
- Completed experimental delivery verification with custom-preset manual/pressure/overflow coverage, stock client non-copyability checks, packed design/ADR documentation, strengthened tarball smoke checks, and a CI-refusing double-confirmed live v2/continuation/restart/repetition harness that remains outside normal `test` and `check`.

### Fixed

- Kept Native replay compatible with sessions that explicitly pin a reasoning effort by applying the same request-header value to Basic's auxiliary Portable call before capturing the Codex payload.

### Security

- Kept generated replay markers and Codex Turn Continuations process-local; credentials, namespaced/wrapped token and auth fields, sensitive headers, raw turn state, and raw account/routing identifiers never enter durable checkpoint state, logs, errors, or diagnostics.
- Added an empty presentation sentinel so stock conversation and Trajectory views do not stringify opaque Native state, and documented that the credential-free block remains sensitive ordinary Session/RPC/export data in rc.2.

## [0.3.1] - 2026-08-27

### Fixed

- Preserved valid tool-result images in Codex requests on newer DSH releases by supplying the adapter's per-image pixel and byte limits.
- Kept the manually constructed Codex profile source-compatible with the DSH `0.1.1-rc.1` minimum while allowing newer adapters to consume those limits.

## [0.3.0] - 2026-08-22

### Added

- Added a live, default-off 1M context policy for GPT-5.6 Luna, Sol, and Terra through the new `codex-llm` Settings namespace.
- Added accessible collapse/expand controls for the detailed Web Search and Image Creation settings.

### Changed

- Reordered GPT Auth Settings to place LLM Context immediately below Login and matched login-action sizing to the Antigravity settings panel.

## [0.2.3] - 2026-08-21

### Changed

- Raised the minimum DeepSeek Harness baseline to `0.1.1-rc.1` across peer dependencies, development dependencies, documentation, and reproducible workspace resolution.
- Adapted the Codex LLM route to the required `PiAiAdapterOptions.auth` contract while preserving the plugin-owned Host credential coordinator as the only token source.
- Added the rc.1 request image payload default and attachment dimension limit to the adapter and test fixtures.
- Updated packaged-artifact validation to verify declared rc.1 resolutions without rejecting legitimate older transitive snapshots embedded by upstream packages.

### Security

- Kept pi-ai credential persistence and ambient discovery fail-closed so Codex tokens cannot enter a second credential path, client state, or RPC payloads.

## [0.2.2] - 2026-08-20

### Fixed

- Restored generated-image rendering on DSH rc.7+ by owning the gallery in this client bundle instead of importing React values from the attachment plugin browser face, which does not expose presentation components.

## [0.2.1] - 2026-08-20

### Changed

- Refined the GPT Auth settings UI with compact cards, header status indication, native-style capability toggles, quota progress feedback, and stable skeleton/refresh states.
- Raised the minimum DeepSeek Harness baseline to `0.1.0-rc.7` across peer dependencies, development dependencies, and reproducible workspace resolution.
- Documented that rc.7 exposes the plugin-owned `codex-search` and `codex-image` settings namespaces while the existing top-level `settings.section` registration remains compatible.
- Documented rc.7 ACP image admission: persisted user images participate in the Image Catalog and reference flow, while generated tool-result images are not projected directly over ACP.
- Hardened packaged-artifact smoke checks so manifest ranges semantically enforce the rc.7 floor and the lockfile rejects every pre-rc.7 DSH resolution.

### Fixed

- Made auth work lifecycle-safe across overlapping Host coordinators with per-instance singleflight, disposal-abortable network/probe work, bounded caller detachment, and coordinated atomic commits.
- Restored the visible Host-only token privacy disclosure and made settings loading/reduced-motion behavior accessible.

## [0.2.0] - 2026-08-14

### Added

- Codex-backed Web Search through the stock DSH `web_search` tool, with deployment-global provider selection, bounded responses, cancellation, and conservative retry behavior.
- Durable `generate_image` and model-facing `list_images` tools with image references, deployment limits, partial-success handling, session-authorized attachments, and paginated catalogs.
- A unified bilingual GPT Auth settings section for Login, Web Search, and Image Creation.
- Resilient weekly Codex usage status with bounded Host requests and value-free browser projections.
- Independent Host composition rows for Auth/LLM, Search, and Image, including coordinator-only operation through `llmEnabled: false`.

### Changed

- Centralized Codex Login State behind a shared lock-coordinated Host service with locked re-reads and conservative same-account recovery.
- Successful image generation now displays only the standard image gallery; `list_images` has no user-facing result card.
- Expanded packed-artifact validation to import published Host exports and verify the browser bundle and composition patch.
- Updated English and Chinese documentation for the complete Codex capability bundle.

### Security

- Token values remain Host-only and are excluded from browser state, settings, logs, events, diagnostics, and tool metadata.
- Workspace image reads stay bounded and policy-aware, while durable image reads require authorization from the owning session log.

### Known limitation

- DSH `0.1.0-rc.6` does not expose a policy-aware binary workspace-write API, so generated images remain durable conversation attachments and workspace export is not offered.

[Unreleased]: https://github.com/suntianc/dsh-codex-auth/compare/v0.3.4-rc.2...HEAD
[0.3.4-rc.2]: https://github.com/suntianc/dsh-codex-auth/compare/v0.3.4-rc.1...v0.3.4-rc.2
[0.3.3-alpha.5]: https://github.com/suntianc/dsh-codex-auth/compare/v0.3.2...v0.3.3-alpha.5
[0.3.2]: https://github.com/suntianc/dsh-codex-auth/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/suntianc/dsh-codex-auth/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/suntianc/dsh-codex-auth/compare/v0.2.3...v0.3.0
[0.2.3]: https://github.com/suntianc/dsh-codex-auth/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/suntianc/dsh-codex-auth/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/suntianc/dsh-codex-auth/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/suntianc/dsh-codex-auth/compare/v0.1.0...v0.2.0
