/**
 * Send pi-ai's compressed SSE body as JSON, preserving the request and response semantics.
 * @param fetchImpl - request-owned HTTP transport, including proxy and cancellation handling.
 * @returns a scoped fetch implementation; non-zstd requests pass through unchanged.
 */
export declare function codexJsonFetch(fetchImpl: typeof fetch): typeof fetch;
//# sourceMappingURL=codex-transport.d.ts.map